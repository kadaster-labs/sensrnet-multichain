# Copyright(C) 2011,2012,2013,2014 by Abe developers.

# DataStore.py: back end database access for Abe.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Affero General Public License for more details.
# 
# You should have received a copy of the GNU Affero General Public
# License along with this program.  If not, see
# <http://www.gnu.org/licenses/agpl.html>.

# This module combines three functions that might be better split up:
# 1. Abe's schema
# 2. Abstraction over the schema for importing blocks, etc.
# 3. Code to load data by scanning blockfiles or using JSON-RPC.

import os
import re
import time
import errno
import logging

import SqlAbstraction

import Chain

# bitcointools -- modified deserialize.py to return raw transaction
import BCDataStream
import deserialize
import util
import base58

# MULTICHAIN START
import binascii
import struct
# MULTICHAIN END

SCHEMA_TYPE = "Abe"
SCHEMA_VERSION = SCHEMA_TYPE + "40"

CONFIG_DEFAULTS = {
    "dbtype":             None,
    "connect_args":       None,
    "binary_type":        None,
    "int_type":           None,
    "upgrade":            None,
    "rescan":             None,
    "commit_bytes":       None,
    "log_sql":            None,
    "log_rpc":            None,
    "default_chain":      "Bitcoin",
    "datadir":            None,
    "ignore_bit8_chains": None,
    "use_firstbits":      False,
    "keep_scriptsig":     True,
    "import_tx":          [],
    "default_loader":     "default",
    "rpc_load_mempool":   False,
# MULTICHAIN START
    "home_refresh_interval_secs": 60,
    "recent_tx_interval_ms": 5000,
    "catch_up_tx_interval_secs": 60
# MULTICHAIN END
}

WORK_BITS = 304  # XXX more than necessary.

CHAIN_CONFIG = [
#    {"chain":"Bitcoin"},
#    {"chain":"Testnet"},
    #{"chain":"",
    # "code3":"", "address_version":"\x", "magic":""},
# MULTICHAIN START
#    {"chain":"MultiChain"}
# MULTICHAIN END
    ]

NULL_PUBKEY_HASH = "\0" * Chain.PUBKEY_HASH_LENGTH
NULL_PUBKEY_ID = 0
PUBKEY_ID_NETWORK_FEE = NULL_PUBKEY_ID

# MULTICHAIN START
PUBKEY_FLAGS_P2SH = 1<<0
# MULTICHAIN END

# Size of the script and pubkey columns in bytes.
MAX_SCRIPT = 1000000
MAX_PUBKEY = 65

NO_CLOB = 'BUG_NO_CLOB'

# XXX This belongs in another module.
class InvalidBlock(Exception):
    pass
class MerkleRootMismatch(InvalidBlock):
    def __init__(ex, block_hash, tx_hashes):
        ex.block_hash = block_hash
        ex.tx_hashes = tx_hashes
    def __str__(ex):
        return 'Block header Merkle root does not match its transactions. ' \
            'block hash=%s' % (ex.block_hash[::-1].encode('hex'),)

class MalformedHash(ValueError):
    pass

class MalformedAddress(ValueError):
    pass

class DataStore(object):

    """
    Bitcoin data storage class based on DB-API 2 and standard SQL with
    workarounds to support SQLite3, PostgreSQL/psycopg2, MySQL,
    Oracle, ODBC, and IBM DB2.
    """

    def __init__(store, args):
        """
        Open and store a connection to the SQL database.

        args.dbtype should name a DB-API 2 driver module, e.g.,
        "sqlite3".

        args.connect_args should be an argument to the module's
        connect() method, or None for no argument, or a list of
        arguments, or a dictionary of named arguments.

        args.datadir names Bitcoin data directories containing
        blk0001.dat to scan for new blocks.
        """
        if args.datadir is None:
            args.datadir = util.determine_db_dir()
        if isinstance(args.datadir, str):
            args.datadir = [args.datadir]

        store.args = args
        store.log = logging.getLogger(__name__)

        store.rpclog = logging.getLogger(__name__ + ".rpc")
        if not args.log_rpc:
            store.rpclog.setLevel(logging.ERROR)

        if args.dbtype is None:
            store.log.warn("dbtype not configured, see abe.conf for examples");
            store.dbmodule = None
            store.config = CONFIG_DEFAULTS.copy()
            store.datadirs = []
            store.use_firstbits = CONFIG_DEFAULTS['use_firstbits']
            store._sql = None
            return
        store.dbmodule = __import__(args.dbtype)

        sql_args = lambda: 1
        sql_args.module = store.dbmodule
        sql_args.connect_args = args.connect_args
        sql_args.binary_type = args.binary_type
        sql_args.int_type = args.int_type
        sql_args.log_sql = args.log_sql
        sql_args.prefix = "abe_"
        sql_args.config = {}
        store.sql_args = sql_args
        store.set_db(None)
        store.init_sql()

        store._blocks = {}

        # Read the CONFIG and CONFIGVAR tables if present.
        store.config = store._read_config()

        if store.config is None:
            store.keep_scriptsig = args.keep_scriptsig
        elif 'keep_scriptsig' in store.config:
            store.keep_scriptsig = store.config.get('keep_scriptsig') == "true"
        else:
            store.keep_scriptsig = CONFIG_DEFAULTS['keep_scriptsig']

        store.refresh_ddl()

        if store.config is None:
            store.initialize()
        else:
            store.init_sql()

            if store.config['schema_version'] == SCHEMA_VERSION:
                pass
            elif args.upgrade:
                import upgrade
                upgrade.upgrade_schema(store)
            else:
                raise Exception(
                    "Database schema version (%s) does not match software"
                    " (%s).  Please run with --upgrade to convert database."
                    % (store.config['schema_version'], SCHEMA_VERSION))
        store._sql.auto_reconnect = True

        if args.rescan:
            store.sql("UPDATE datadir SET blkfile_number=1, blkfile_offset=0")

        store._init_datadirs()
        store.init_chains()

        store.commit_bytes = args.commit_bytes
        if store.commit_bytes is None:
            store.commit_bytes = 0  # Commit whenever possible.
        else:
            store.commit_bytes = int(store.commit_bytes)
        store.bytes_since_commit = 0

        store.use_firstbits = (store.config['use_firstbits'] == "true")

        for hex_tx in args.import_tx:
            chain_name = None
            if isinstance(hex_tx, dict):
                chain_name = hex_tx.get("chain")
                hex_tx = hex_tx.get("tx")
            store.maybe_import_binary_tx(chain_name, str(hex_tx).decode('hex'))

        store.default_loader = args.default_loader

        store.rpc_load_mempool = args.rpc_load_mempool

        store.default_chain = args.default_chain;

# MULTICHAIN START
        store.home_refresh_interval_secs = args.home_refresh_interval_secs
        store.recent_tx_interval_ms = args.recent_tx_interval_ms
        store.catch_up_tx_interval_secs = args.catch_up_tx_interval_secs
# MULTICHAIN END

        store.commit()

    def set_db(store, db):
        store._sql = db

    def get_db(store):
        return store._sql

    def connect(store):
        return store._sql.connect()

    def reconnect(store):
        return store._sql.reconnect()

    def close(store):
        store._sql.close()

    def commit(store):
        store._sql.commit()

    def rollback(store):
        if store._sql is not None:
            store._sql.rollback()

    def sql(store, stmt, params=()):
        store._sql.sql(stmt, params)

    def ddl(store, stmt):
        store._sql.ddl(stmt)

    def selectrow(store, stmt, params=()):
        return store._sql.selectrow(stmt, params)

    def selectall(store, stmt, params=()):
        return store._sql.selectall(stmt, params)

    def rowcount(store):
        return store._sql.rowcount()

    def create_sequence(store, key):
        store._sql.create_sequence(key)

    def drop_sequence(store, key):
        store._sql.drop_sequence(key)

    def new_id(store, key):
        return store._sql.new_id(key)

    def init_sql(store):
        sql_args = store.sql_args
        if hasattr(store, 'config'):
            for name in store.config.keys():
                if name.startswith('sql.'):
                    sql_args.config[name[len('sql.'):]] = store.config[name]
        if store._sql:
            store._sql.close()  # XXX Could just set_flavour.
        store.set_db(SqlAbstraction.SqlAbstraction(sql_args))
        store.init_binfuncs()

    def init_binfuncs(store):
        store.binin       = store._sql.binin
        store.binin_hex   = store._sql.binin_hex
        store.binin_int   = store._sql.binin_int
        store.binout      = store._sql.binout
        store.binout_hex  = store._sql.binout_hex
        store.binout_int  = store._sql.binout_int
        store.intin       = store._sql.intin
        store.hashin      = store._sql.revin
        store.hashin_hex  = store._sql.revin_hex
        store.hashout     = store._sql.revout
        store.hashout_hex = store._sql.revout_hex

    def _read_config(store):
        # Read table CONFIGVAR if it exists.
        config = {}
        try:
            for name, value in store.selectall("""
                SELECT configvar_name, configvar_value
                  FROM configvar"""):
                config[name] = '' if value is None else value
            if config:
                return config

        except store.dbmodule.DatabaseError:
            try:
                store.rollback()
            except Exception:
                pass

        # Read legacy table CONFIG if it exists.
        try:
            row = store.selectrow("""
                SELECT schema_version, binary_type
                  FROM config
                 WHERE config_id = 1""")
            sv, btype = row
            return { 'schema_version': sv, 'binary_type': btype }
        except Exception:
            try:
                store.rollback()
            except Exception:
                pass

        # Return None to indicate no schema found.
        return None

    def _init_datadirs(store):
        """Parse store.args.datadir, create store.datadirs."""
        if store.args.datadir == []:
            store.datadirs = []
            return

        datadirs = {}
        for row in store.selectall("""
            SELECT datadir_id, dirname, blkfile_number, blkfile_offset,
                   chain_id
              FROM datadir"""):
            id, dir, num, offs, chain_id = row
            datadirs[dir] = {
                "id": id,
                "dirname": dir,
                "blkfile_number": int(num),
                "blkfile_offset": int(offs),
                "chain_id": None if chain_id is None else int(chain_id),
                "loader": None}

        #print("datadirs: %r" % datadirs)

        # By default, scan every dir we know.  This doesn't happen in
        # practise, because abe.py sets ~/.bitcoin as default datadir.
        if store.args.datadir is None:
            store.datadirs = datadirs.values()
            return

        def lookup_chain_id(name):
            row = store.selectrow(
                "SELECT chain_id FROM chain WHERE chain_name = ?",
                (name,))
            return None if row is None else int(row[0])

        store.datadirs = []
        for dircfg in store.args.datadir:
            loader = None
            conf = None

            if isinstance(dircfg, dict):
                #print("dircfg is dict: %r" % dircfg)  # XXX
                dirname = dircfg.get('dirname')
                if dirname is None:
                    raise ValueError(
                        'Missing dirname in datadir configuration: '
                        + str(dircfg))
                if dirname in datadirs:
                    d = datadirs[dirname]
                    d['loader'] = dircfg.get('loader')
                    d['conf'] = dircfg.get('conf')
                    if d['chain_id'] is None and 'chain' in dircfg:
                        d['chain_id'] = lookup_chain_id(dircfg['chain'])
                    store.datadirs.append(d)
                    continue

                loader = dircfg.get('loader')
                conf = dircfg.get('conf')
                chain_id = dircfg.get('chain_id')
                if chain_id is None:
                    chain_name = dircfg.get('chain')
                    chain_id = lookup_chain_id(chain_name)

                    if chain_id is None and chain_name is not None:
                        chain_id = store.new_id('chain')

                        code3 = dircfg.get('code3')
                        if code3 is None:
                            # XXX Should default via policy.
                            code3 = '000' if chain_id > 999 else "%03d" % (
                                chain_id,)
# MULTICHAIN START
                        paramsdat_broken = False
                        paramsfile = os.path.join(os.path.expanduser(dirname), "params.dat")
                        try:
                            params = {}
                            for line in open(paramsfile):
                                if "=" not in line:
                                    continue
                                x = line.partition('#')[0].split("=", 1)
                                if len(x) != 2:
                                    continue
                                params[x[0].strip()]=x[1].strip()
                        except Exception, e:
                            store.log.error("failed to load %s: %s", paramsfile, e)
                            paramsdat_broken = True

                        if paramsdat_broken is False:
                            x = params.get("address-pubkeyhash-version","00").strip()
                            addr_vers = binascii.unhexlify(x)
                            x = params.get("address-scripthash-version","05").strip()
                            script_addr_vers = binascii.unhexlify(x)
                            x = params.get("address-checksum-value","00000000").strip()
                            address_checksum = binascii.unhexlify(x)
                            x = params.get("network-message-start","f9beb4d9").strip()
                            chain_magic = binascii.unhexlify(x)
                            protocol_version = params.get("protocol-version",10007)
                        else:
                            protocol_version = 10007
                            chain_magic = '\xf9\xbe\xb4\xd9'
                            address_checksum = "\0\0\0\0"
                            addr_vers = dircfg.get('address_version')
                            if addr_vers is None:
                                addr_vers = "\0"
                            elif isinstance(addr_vers, unicode):
                                addr_vers = addr_vers.encode('latin_1')

                            script_addr_vers = dircfg.get('script_addr_vers')
                            if script_addr_vers is None:
                                script_addr_vers = "\x05"
                            elif isinstance(script_addr_vers, unicode):
                                script_addr_vers = script_addr_vers.encode('latin_1')
# MULTICHAIN END
                        decimals = dircfg.get('decimals')
                        if decimals is not None:
                            decimals = int(decimals)

                        # XXX Could do chain_magic, but this datadir won't
                        # use it, because it knows its chain.
# MULTICHAIN START
                        store.sql("""
                            INSERT INTO chain (
                                chain_id, chain_name, chain_code3,
                                chain_magic, chain_address_checksum, chain_address_version, chain_script_addr_vers, chain_policy,
                                chain_decimals, chain_protocol_version
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                                  (chain_id, chain_name, code3,
                                   store.binin(chain_magic), store.binin(address_checksum), store.binin(addr_vers), store.binin(script_addr_vers),
# MULTICHAIN END
                                   dircfg.get('policy', chain_name), decimals, protocol_version))
                        store.commit()
                        store.log.warning("Assigned chain_id %d to %s",
                                          chain_id, chain_name)

            elif dircfg in datadirs:
                store.datadirs.append(datadirs[dircfg])
                continue
            else:
                # Not a dict.  A string naming a directory holding
                # standard chains.
                dirname = dircfg
                chain_id = None

            d = {
                "id": store.new_id("datadir"),
                "dirname": dirname,
                "blkfile_number": 1,
                "blkfile_offset": 0,
                "chain_id": chain_id,
                "loader": loader,
                "conf": conf,
                }
            store.datadirs.append(d)

    def init_chains(store):
        store.chains_by = lambda: 0
        store.chains_by.id = {}
        store.chains_by.name = {}
        store.chains_by.magic = {}

        # Legacy config option.
        no_bit8_chains = store.args.ignore_bit8_chains or []
        if isinstance(no_bit8_chains, str):
            no_bit8_chains = [no_bit8_chains]
# MULTICHAIN START
        for chain_id, magic, chain_name, chain_code3, address_checksum, address_version, script_addr_vers, \
                chain_policy, chain_decimals, chain_protocol_version in \
                store.selectall("""
                    SELECT chain_id, chain_magic, chain_name, chain_code3,
                           chain_address_checksum, chain_address_version, chain_script_addr_vers, chain_policy, chain_decimals,
                           chain_protocol_version
                      FROM chain
                """):
# MULTICHAIN END
            chain = Chain.create(
                id              = int(chain_id),
                magic           = store.binout(magic),
                name            = unicode(chain_name),
                code3           = chain_code3 and unicode(chain_code3),
# MULTICHAIN START
                address_checksum = store.binout(address_checksum),
                protocol_version = int(chain_protocol_version),
# MULTICHAIN END
                address_version = store.binout(address_version),
                script_addr_vers = store.binout(script_addr_vers),
                policy          = unicode(chain_policy),
                decimals        = None if chain_decimals is None else \
                    int(chain_decimals))

            # Legacy config option.
            if chain.name in no_bit8_chains and \
                    chain.has_feature('block_version_bit8_merge_mine'):
                chain = Chain.create(src=chain, policy="LegacyNoBit8")

            store.chains_by.id[chain.id] = chain
            store.chains_by.name[chain.name] = chain
            store.chains_by.magic[bytes(chain.magic)] = chain

    def get_chain_by_id(store, chain_id):
        return store.chains_by.id[int(chain_id)]

    def get_chain_by_name(store, name):
        return store.chains_by.name.get(name, None)

    def get_default_chain(store):
        store.log.debug("Falling back to default (Bitcoin) policy.")
        return Chain.create(store.default_chain)

# MULTICHAIN START
    def get_url_by_chain(store, chain):
        dirname = store.get_dirname_by_id(chain.id)
        conffile = chain.datadir_conf_file_name
        conffile = os.path.join(dirname, conffile)
        try:
            conf = dict([line.strip().split("=", 1)
                         if "=" in line
                         else (line.strip(), True)
                         for line in open(conffile)
                         if line != "" and line[0] not in "#\r\n"])
        except Exception, e:
            store.log.error("failed to load %s: %s", conffile, e)
            return None

        rpcuser     = conf.get("rpcuser", "")
        rpcpassword = conf["rpcpassword"]
        rpcconnect  = conf.get("rpcconnect", "127.0.0.1")
        rpcport     = conf.get("rpcport", chain.datadir_rpcport)
        url = "http://" + rpcuser + ":" + rpcpassword + "@" + rpcconnect \
            + ":" + str(rpcport)
        return url

    def get_multichain_name_by_id(store, chain_id):
        dirname = store.get_dirname_by_id( chain_id)
        if dirname is None:
            return None
        return os.path.basename(dirname)

    def get_dirname_by_id(store, chain_id):
        """
        Get the chain name of a multichain network, given the chain id.
        :param store:
        :param chain_id:
        :return:
        """
        chain_id = int(chain_id)
        row = store.selectrow("""
                SELECT dirname
                  FROM datadir
                 WHERE chain_id = ?""", (chain_id,))
        if row is None:
            return None
        dirname, = row
        return dirname


# MULTICHAIN END


    def get_ddl(store, key):
        return store._ddl[key]

    def refresh_ddl(store):
        store._ddl = {
            "chain_summary":
# XXX I could do a lot with MATERIALIZED views.
"""CREATE VIEW chain_summary AS SELECT
    cc.chain_id,
    cc.in_longest,
    b.block_id,
    b.block_hash,
    b.block_version,
    b.block_hashMerkleRoot,
    b.block_nTime,
    b.block_nBits,
    b.block_nNonce,
    cc.block_height,
    b.prev_block_id,
    prev.block_hash prev_block_hash,
    b.block_chain_work,
    b.block_num_tx,
    b.block_value_in,
    b.block_value_out,
    b.block_total_satoshis,
    b.block_total_seconds,
    b.block_satoshi_seconds,
    b.block_total_ss,
    b.block_ss_destroyed
FROM chain_candidate cc
JOIN block b ON (cc.block_id = b.block_id)
LEFT JOIN block prev ON (b.prev_block_id = prev.block_id)""",

            "txout_detail":
"""CREATE VIEW txout_detail AS SELECT
    cc.chain_id,
    cc.in_longest,
    cc.block_id,
    b.block_hash,
    b.block_height,
    block_tx.tx_pos,
    tx.tx_id,
    tx.tx_hash,
    tx.tx_lockTime,
    tx.tx_version,
    tx.tx_size,
    txout.txout_id,
    txout.txout_pos,
    txout.txout_value,
    txout.txout_scriptPubKey,
    pubkey.pubkey_id,
    pubkey.pubkey_hash,
    pubkey.pubkey
  FROM chain_candidate cc
  JOIN block b ON (cc.block_id = b.block_id)
  JOIN block_tx ON (b.block_id = block_tx.block_id)
  JOIN tx    ON (tx.tx_id = block_tx.tx_id)
  JOIN txout ON (tx.tx_id = txout.tx_id)
  LEFT JOIN pubkey ON (txout.pubkey_id = pubkey.pubkey_id)""",

            "txin_detail":
"""CREATE VIEW txin_detail AS SELECT
    cc.chain_id,
    cc.in_longest,
    cc.block_id,
    b.block_hash,
    b.block_height,
    block_tx.tx_pos,
    tx.tx_id,
    tx.tx_hash,
    tx.tx_lockTime,
    tx.tx_version,
    tx.tx_size,
    txin.txin_id,
    txin.txin_pos,
    txin.txout_id prevout_id""" + (""",
    txin.txin_scriptSig,
    txin.txin_sequence""" if store.keep_scriptsig else """,
    NULL txin_scriptSig,
    NULL txin_sequence""") + """,
    prevout.txout_value txin_value,
    prevout.txout_scriptPubKey txin_scriptPubKey,
    pubkey.pubkey_id,
    pubkey.pubkey_hash,
    pubkey.pubkey
  FROM chain_candidate cc
  JOIN block b ON (cc.block_id = b.block_id)
  JOIN block_tx ON (b.block_id = block_tx.block_id)
  JOIN tx    ON (tx.tx_id = block_tx.tx_id)
  JOIN txin  ON (tx.tx_id = txin.tx_id)
  LEFT JOIN txout prevout ON (txin.txout_id = prevout.txout_id)
  LEFT JOIN pubkey
      ON (prevout.pubkey_id = pubkey.pubkey_id)""",

            "txout_approx":
# View of txout for drivers like sqlite3 that can not handle large
# integer arithmetic.  For them, we transform the definition of
# txout_approx_value to DOUBLE PRECISION (approximate) by a CAST.
"""CREATE VIEW txout_approx AS SELECT
    txout_id,
    tx_id,
    txout_value txout_approx_value
  FROM txout""",

            "configvar":
# ABE accounting.  This table is read without knowledge of the
# database's SQL quirks, so it must use only the most widely supported
# features.
"""CREATE TABLE configvar (
    configvar_name  VARCHAR(100) NOT NULL PRIMARY KEY,
    configvar_value VARCHAR(255)
)""",

            "abe_sequences":
"""CREATE TABLE abe_sequences (
    sequence_key VARCHAR(100) NOT NULL PRIMARY KEY,
    nextid NUMERIC(30)
)""",
            }

    def initialize(store):
        """
        Create the database schema.
        """
        store.config = {}
        store.configure()

        for stmt in (

store._ddl['configvar'],

"""CREATE TABLE datadir (
    datadir_id  NUMERIC(10) NOT NULL PRIMARY KEY,
    dirname     VARCHAR(2000) NOT NULL,
    blkfile_number NUMERIC(8) NULL,
    blkfile_offset NUMERIC(20) NULL,
    chain_id    NUMERIC(10) NULL
)""",

# A block of the type used by Bitcoin.
"""CREATE TABLE block (
    block_id      NUMERIC(14) NOT NULL PRIMARY KEY,
    block_hash    BINARY(32)  UNIQUE NOT NULL,
    block_version NUMERIC(10),
    block_hashMerkleRoot BINARY(32),
    block_nTime   NUMERIC(20),
    block_nBits   NUMERIC(10),
    block_nNonce  NUMERIC(10),
    block_height  NUMERIC(14) NULL,
    prev_block_id NUMERIC(14) NULL,
    search_block_id NUMERIC(14) NULL,
    block_chain_work BINARY(""" + str(WORK_BITS / 8) + """),
    block_value_in NUMERIC(30) NULL,
    block_value_out NUMERIC(30),
    block_total_satoshis NUMERIC(26) NULL,
    block_total_seconds NUMERIC(20) NULL,
    block_satoshi_seconds NUMERIC(28) NULL,
    block_total_ss NUMERIC(28) NULL,
    block_num_tx  NUMERIC(10) NOT NULL,
    block_ss_destroyed NUMERIC(28) NULL,
    FOREIGN KEY (prev_block_id)
        REFERENCES block (block_id),
    FOREIGN KEY (search_block_id)
        REFERENCES block (block_id)
)""",

# CHAIN comprises a magic number, a policy, and (indirectly via
# CHAIN_LAST_BLOCK_ID and the referenced block's ancestors) a genesis
# block, possibly null.  A chain may have a currency code.
"""CREATE TABLE chain (
    chain_id    NUMERIC(10) NOT NULL PRIMARY KEY,
    chain_name  VARCHAR(100) UNIQUE NOT NULL,
    chain_code3 VARCHAR(5)  NULL,
    chain_address_version VARBINARY(100) NOT NULL,
    chain_script_addr_vers VARBINARY(100) NULL,
    chain_address_checksum VARBINARY(100) NULL,
    chain_magic BINARY(4)     NULL,
    chain_policy VARCHAR(255) NOT NULL,
    chain_decimals NUMERIC(2) NULL,
    chain_last_block_id NUMERIC(14) NULL,
    chain_protocol_version NUMERIC(10) NOT NULL,
    FOREIGN KEY (chain_last_block_id)
        REFERENCES block (block_id)
)""",

# CHAIN_CANDIDATE lists blocks that are, or might become, part of the
# given chain.  IN_LONGEST is 1 when the block is in the chain, else 0.
# IN_LONGEST denormalizes information stored canonically in
# CHAIN.CHAIN_LAST_BLOCK_ID and BLOCK.PREV_BLOCK_ID.
"""CREATE TABLE chain_candidate (
    chain_id      NUMERIC(10) NOT NULL,
    block_id      NUMERIC(14) NOT NULL,
    in_longest    NUMERIC(1),
    block_height  NUMERIC(14),
    PRIMARY KEY (chain_id, block_id),
    FOREIGN KEY (block_id) REFERENCES block (block_id)
)""",
"""CREATE INDEX x_cc_block ON chain_candidate (block_id)""",
"""CREATE INDEX x_cc_chain_block_height
    ON chain_candidate (chain_id, block_height)""",
"""CREATE INDEX x_cc_block_height ON chain_candidate (block_height)""",

# An orphan block must remember its hashPrev.
"""CREATE TABLE orphan_block (
    block_id      NUMERIC(14) NOT NULL PRIMARY KEY,
    block_hashPrev BINARY(32) NOT NULL,
    FOREIGN KEY (block_id) REFERENCES block (block_id)
)""",
"""CREATE INDEX x_orphan_block_hashPrev ON orphan_block (block_hashPrev)""",

# Denormalize the relationship inverse to BLOCK.PREV_BLOCK_ID.
"""CREATE TABLE block_next (
    block_id      NUMERIC(14) NOT NULL,
    next_block_id NUMERIC(14) NOT NULL,
    PRIMARY KEY (block_id, next_block_id),
    FOREIGN KEY (block_id) REFERENCES block (block_id),
    FOREIGN KEY (next_block_id) REFERENCES block (block_id)
)""",

# A transaction of the type used by Bitcoin.
"""CREATE TABLE tx (
    tx_id         NUMERIC(26) NOT NULL PRIMARY KEY,
    tx_hash       BINARY(32)  UNIQUE NOT NULL,
    tx_version    NUMERIC(10),
    tx_lockTime   NUMERIC(10),
    tx_size       NUMERIC(10)
)""",

# Presence of transactions in blocks is many-to-many.
"""CREATE TABLE block_tx (
    block_id      NUMERIC(14) NOT NULL,
    tx_id         NUMERIC(26) NOT NULL,
    tx_pos        NUMERIC(10) NOT NULL,
    PRIMARY KEY (block_id, tx_id),
    UNIQUE (block_id, tx_pos),
    FOREIGN KEY (block_id)
        REFERENCES block (block_id),
    FOREIGN KEY (tx_id)
        REFERENCES tx (tx_id)
)""",
"""CREATE INDEX x_block_tx_tx ON block_tx (tx_id)""",

# A public key for sending bitcoins.  PUBKEY_HASH is derivable from a
# Bitcoin or Testnet address.
"""CREATE TABLE pubkey (
    pubkey_id     NUMERIC(26) NOT NULL PRIMARY KEY,
    pubkey_hash   BINARY(20)  UNIQUE NOT NULL,
    pubkey        VARBINARY(""" + str(MAX_PUBKEY) + """) NULL,
    pubkey_flags  NUMERIC(32) NULL
)""",

"""CREATE TABLE multisig_pubkey (
    multisig_id   NUMERIC(26) NOT NULL,
    pubkey_id     NUMERIC(26) NOT NULL,
    PRIMARY KEY (multisig_id, pubkey_id),
    FOREIGN KEY (multisig_id) REFERENCES pubkey (pubkey_id),
    FOREIGN KEY (pubkey_id) REFERENCES pubkey (pubkey_id)
)""",
"""CREATE INDEX x_multisig_pubkey_pubkey ON multisig_pubkey (pubkey_id)""",

# A transaction out-point.
"""CREATE TABLE txout (
    txout_id      NUMERIC(26) NOT NULL PRIMARY KEY,
    tx_id         NUMERIC(26) NOT NULL,
    txout_pos     NUMERIC(10) NOT NULL,
    txout_value   NUMERIC(30) NOT NULL,
    txout_scriptPubKey VARBINARY(""" + str(MAX_SCRIPT) + """),
    pubkey_id     NUMERIC(26),
    UNIQUE (tx_id, txout_pos),
    FOREIGN KEY (pubkey_id)
        REFERENCES pubkey (pubkey_id)
)""",
"""CREATE INDEX x_txout_pubkey ON txout (pubkey_id)""",

# A transaction in-point.
"""CREATE TABLE txin (
    txin_id       NUMERIC(26) NOT NULL PRIMARY KEY,
    tx_id         NUMERIC(26) NOT NULL,
    txin_pos      NUMERIC(10) NOT NULL,
    txout_id      NUMERIC(26)""" + (""",
    txin_scriptSig VARBINARY(""" + str(MAX_SCRIPT) + """),
    txin_sequence NUMERIC(10)""" if store.keep_scriptsig else "") + """,
    UNIQUE (tx_id, txin_pos),
    FOREIGN KEY (tx_id)
        REFERENCES tx (tx_id)
)""",
"""CREATE INDEX x_txin_txout ON txin (txout_id)""",

# While TXIN.TXOUT_ID can not be found, we must remember TXOUT_POS,
# a.k.a. PREVOUT_N.
"""CREATE TABLE unlinked_txin (
    txin_id       NUMERIC(26) NOT NULL PRIMARY KEY,
    txout_tx_hash BINARY(32)  NOT NULL,
    txout_pos     NUMERIC(10) NOT NULL,
    FOREIGN KEY (txin_id) REFERENCES txin (txin_id)
)""",
"""CREATE INDEX x_unlinked_txin_outpoint
    ON unlinked_txin (txout_tx_hash, txout_pos)""",

"""CREATE TABLE block_txin (
    block_id      NUMERIC(14) NOT NULL,
    txin_id       NUMERIC(26) NOT NULL,
    out_block_id  NUMERIC(14) NOT NULL,
    PRIMARY KEY (block_id, txin_id),
    FOREIGN KEY (block_id) REFERENCES block (block_id),
    FOREIGN KEY (txin_id) REFERENCES txin (txin_id),
    FOREIGN KEY (out_block_id) REFERENCES block (block_id)
)""",

store._ddl['chain_summary'],
store._ddl['txout_detail'],
store._ddl['txin_detail'],
store._ddl['txout_approx'],

"""CREATE TABLE abe_lock (
    lock_id       NUMERIC(10) NOT NULL PRIMARY KEY,
    pid           VARCHAR(255) NULL
)""",
# MULTICHAIN START

# issued assets are stored here
# op_drop has issue qty
# op_return of issue asset has: name, multiplier
# 2 steps to get all data.
"""CREATE TABLE asset (
    asset_id      NUMERIC(10) NOT NULL PRIMARY KEY,
    tx_id         NUMERIC(26) NOT NULL,
    chain_id      NUMERIC(10) NOT NULL,
    name          VARCHAR(255) NOT NULL,
    multiplier    NUMERIC(10) NOT NULL,
    issue_qty     NUMERIC(30) NOT NULL,
    prefix        NUMERIC(10) NOT NULL,
    UNIQUE      (tx_id),
    FOREIGN KEY (tx_id) REFERENCES tx (tx_id),
    FOREIGN KEY (chain_id) REFERENCES chain (chain_id)
)""",

"""CREATE TABLE asset_txid (
    asset_id      NUMERIC(10) NOT NULL,
    tx_id         NUMERIC(26) NOT NULL,
    txout_pos     NUMERIC(10) NOT NULL,
    UNIQUE (asset_id, tx_id, txout_pos),
    FOREIGN KEY (tx_id) REFERENCES tx (tx_id),
    FOREIGN KEY (asset_id) REFERENCES asset (asset_id)
)""",

# raw units
"""CREATE TABLE asset_address_balance (
    asset_id      NUMERIC(10) NOT NULL,
    pubkey_id     NUMERIC(26) NOT NULL,
    balance       NUMERIC(30) NOT NULL,
    PRIMARY KEY (asset_id, pubkey_id),
    FOREIGN KEY (asset_id) REFERENCES asset (asset_id),
    FOREIGN KEY (pubkey_id) REFERENCES pubkey (pubkey_id)
)""",


# MULTICHAIN END
):
            try:
                store.ddl(stmt)
            except Exception:
                store.log.error("Failed: %s", stmt)
                raise

        for key in ['chain', 'datadir',
# MULTICHAIN START
                    'asset',
# MULTICHAIN END
                    'tx', 'txout', 'pubkey', 'txin', 'block']:
            store.create_sequence(key)

        store.sql("INSERT INTO abe_lock (lock_id) VALUES (1)")

        # Insert some well-known chain metadata.
        for conf in CHAIN_CONFIG:
            conf = conf.copy()
            conf["name"] = conf.pop("chain")
            if 'policy' in conf:
                policy = conf.pop('policy')
            else:
                policy = conf['name']

            chain = Chain.create(policy, **conf)
            store.insert_chain(chain)

        store.sql("""
            INSERT INTO pubkey (pubkey_id, pubkey_hash) VALUES (?, ?)""",
                  (NULL_PUBKEY_ID, store.binin(NULL_PUBKEY_HASH)))

        if store.args.use_firstbits:
            store.config['use_firstbits'] = "true"
            store.ddl(
                """CREATE TABLE abe_firstbits (
                    pubkey_id       NUMERIC(26) NOT NULL,
                    block_id        NUMERIC(14) NOT NULL,
                    address_version VARBINARY(10) NOT NULL,
                    firstbits       VARCHAR(50) NOT NULL,
                    PRIMARY KEY (address_version, pubkey_id, block_id),
                    FOREIGN KEY (pubkey_id) REFERENCES pubkey (pubkey_id),
                    FOREIGN KEY (block_id) REFERENCES block (block_id)
                )""")
            store.ddl(
                """CREATE INDEX x_abe_firstbits
                    ON abe_firstbits (address_version, firstbits)""")
        else:
            store.config['use_firstbits'] = "false"

        store.config['keep_scriptsig'] = \
            "true" if store.args.keep_scriptsig else "false"

        store.save_config()
        store.commit()

    def insert_chain(store, chain):
        chain.id = store.new_id("chain")
# MULTICHAIN START
        store.sql("""
            INSERT INTO chain (
                chain_id, chain_magic, chain_name, chain_code3,
                chain_address_checksum, chain_address_version, chain_script_addr_vers, chain_policy, chain_decimals,
                chain_protocol_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  (chain.id, store.binin(chain.magic), chain.name,
                   chain.code3, store.binin(chain.address_checksum), store.binin(chain.address_version), store.binin(chain.script_addr_vers),
                   chain.policy, chain.decimals, chain.protocol_version))
# MULTICHAIN END

    def get_lock(store):
        if store.version_below('Abe26'):
            return None
        conn = store.connect()
        cur = conn.cursor()
        cur.execute("UPDATE abe_lock SET pid = %d WHERE lock_id = 1"
                    % (os.getpid(),))
        if cur.rowcount != 1:
            raise Exception("unexpected rowcount")
        cur.close()

        # Check whether database supports concurrent updates.  Where it
        # doesn't (SQLite) we get exclusive access automatically.
        try:
            import random
            letters = "".join([chr(random.randint(65, 90)) for x in xrange(10)])
            store.sql("""
                INSERT INTO configvar (configvar_name, configvar_value)
                VALUES (?, ?)""",
                      ("upgrade-lock-" + letters, 'x'))
        except Exception:
            store.release_lock(conn)
            conn = None

        store.rollback()

        # XXX Should reread config.

        return conn

    def release_lock(store, conn):
        if conn:
            conn.rollback()
            conn.close()

    def version_below(store, vers):
        try:
            sv = float(store.config['schema_version'].replace(SCHEMA_TYPE, ''))
        except ValueError:
            return False
        vers = float(vers.replace(SCHEMA_TYPE, ''))
        return sv < vers

    def configure(store):
        config = store._sql.configure()
        store.init_binfuncs()
        for name in config.keys():
            store.config['sql.' + name] = config[name]

    def save_config(store):
        store.config['schema_version'] = SCHEMA_VERSION
        for name in store.config.keys():
            store.save_configvar(name)

    def save_configvar(store, name):
        store.sql("UPDATE configvar SET configvar_value = ?"
                  " WHERE configvar_name = ?", (store.config[name], name))
        if store.rowcount() == 0:
            store.sql("INSERT INTO configvar (configvar_name, configvar_value)"
                      " VALUES (?, ?)", (name, store.config[name]))

    def set_configvar(store, name, value):
        store.config[name] = value
        store.save_configvar(name)

    def cache_block(store, block_id, height, prev_id, search_id):
        assert isinstance(block_id, int), block_id
        assert isinstance(height, int), height
        assert prev_id is None or isinstance(prev_id, int)
        assert search_id is None or isinstance(search_id, int)
        block = {
            'height':    height,
            'prev_id':   prev_id,
            'search_id': search_id}
        store._blocks[block_id] = block
        return block

    def _load_block(store, block_id):
        block = store._blocks.get(block_id)
        if block is None:
            row = store.selectrow("""
                SELECT block_height, prev_block_id, search_block_id
                  FROM block
                 WHERE block_id = ?""", (block_id,))
            if row is None:
                return None
            height, prev_id, search_id = row
            block = store.cache_block(
                block_id, int(height),
                None if prev_id is None else int(prev_id),
                None if search_id is None else int(search_id))
        return block

    def get_block_id_at_height(store, height, descendant_id):
        if height is None:
            return None
        while True:
            block = store._load_block(descendant_id)
            if block['height'] == height:
                return descendant_id
            descendant_id = block[
                'search_id'
                if util.get_search_height(block['height']) >= height else
                'prev_id']

    def is_descended_from(store, block_id, ancestor_id):
#        ret = store._is_descended_from(block_id, ancestor_id)
#        store.log.debug("%d is%s descended from %d", block_id, '' if ret else ' NOT', ancestor_id)
#        return ret
#    def _is_descended_from(store, block_id, ancestor_id):
        block = store._load_block(block_id)
        ancestor = store._load_block(ancestor_id)
        height = ancestor['height']
        return block['height'] >= height and \
            store.get_block_id_at_height(height, block_id) == ancestor_id

    def get_block_height(store, block_id):
        return store._load_block(int(block_id))['height']

    def find_prev(store, hash):
        row = store.selectrow("""
            SELECT block_id, block_height, block_chain_work,
                   block_total_satoshis, block_total_seconds,
                   block_satoshi_seconds, block_total_ss, block_nTime
              FROM block
             WHERE block_hash=?""", (store.hashin(hash),))
        if row is None:
            return (None, None, None, None, None, None, None, None)
        (id, height, chain_work, satoshis, seconds, satoshi_seconds,
         total_ss, nTime) = row
        return (id, None if height is None else int(height),
                store.binout_int(chain_work),
                None if satoshis is None else int(satoshis),
                None if seconds is None else int(seconds),
                None if satoshi_seconds is None else int(satoshi_seconds),
                None if total_ss is None else int(total_ss),
                int(nTime))

    def import_block(store, b, chain_ids=None, chain=None):

        # Import new transactions.

        if chain_ids is None:
            chain_ids = frozenset() if chain is None else frozenset([chain.id])

        b['value_in'] = 0
        b['value_out'] = 0
        b['value_destroyed'] = 0
        tx_hash_array = []

        # In the common case, all the block's txins _are_ linked, and we
        # can avoid a query if we notice this.
        all_txins_linked = True

        for pos in xrange(len(b['transactions'])):
            tx = b['transactions'][pos]

            if 'hash' not in tx:
                if chain is None:
                    store.log.debug("Falling back to SHA256 transaction hash")
                    tx['hash'] = util.double_sha256(tx['__data__'])
                else:
                    tx['hash'] = chain.transaction_hash(tx['__data__'])

            tx_hash_array.append(tx['hash'])
            tx['tx_id'] = store.tx_find_id_and_value(tx, pos == 0)

            if tx['tx_id']:
                all_txins_linked = False
            else:
                if store.commit_bytes == 0:
                    tx['tx_id'] = store.import_and_commit_tx(tx, pos == 0, chain)
                else:
                    tx['tx_id'] = store.import_tx(tx, pos == 0, chain)
                if tx.get('unlinked_count', 1) > 0:
                    all_txins_linked = False

            if tx['value_in'] is None:
                b['value_in'] = None
            elif b['value_in'] is not None:
                b['value_in'] += tx['value_in']
            b['value_out'] += tx['value_out']
            b['value_destroyed'] += tx['value_destroyed']

        # Get a new block ID.
        block_id = int(store.new_id("block"))
        b['block_id'] = block_id

        if chain is not None:
            # Verify Merkle root.
            if b['hashMerkleRoot'] != chain.merkle_root(tx_hash_array):
                raise MerkleRootMismatch(b['hash'], tx_hash_array)

        # Look for the parent block.
        hashPrev = b['hashPrev']
        if chain is None:
            # XXX No longer used.
            is_genesis = hashPrev == util.GENESIS_HASH_PREV
        else:
            is_genesis = hashPrev == chain.genesis_hash_prev

        (prev_block_id, prev_height, prev_work, prev_satoshis,
         prev_seconds, prev_ss, prev_total_ss, prev_nTime) = (
            (None, -1, 0, 0, 0, 0, 0, b['nTime'])
            if is_genesis else
            store.find_prev(hashPrev))

        b['prev_block_id'] = prev_block_id
        b['height'] = None if prev_height is None else prev_height + 1
        b['chain_work'] = util.calculate_work(prev_work, b['nBits'])

        if prev_seconds is None:
            b['seconds'] = None
        else:
            b['seconds'] = prev_seconds + b['nTime'] - prev_nTime
        if prev_satoshis is None or prev_satoshis < 0 or b['value_in'] is None:
            # XXX Abuse this field to save work in adopt_orphans.
            b['satoshis'] = -1 - b['value_destroyed']
        else:
            b['satoshis'] = prev_satoshis + b['value_out'] - b['value_in'] \
                - b['value_destroyed']

        if prev_satoshis is None or prev_satoshis < 0:
            ss_created = None
            b['total_ss'] = None
        else:
            ss_created = prev_satoshis * (b['nTime'] - prev_nTime)
            b['total_ss'] = prev_total_ss + ss_created

        if b['height'] is None or b['height'] < 2:
            b['search_block_id'] = None
        else:
            b['search_block_id'] = store.get_block_id_at_height(
                util.get_search_height(int(b['height'])),
                None if prev_block_id is None else int(prev_block_id))

        # Insert the block table row.
        try:
            store.sql(
                """INSERT INTO block (
                    block_id, block_hash, block_version, block_hashMerkleRoot,
                    block_nTime, block_nBits, block_nNonce, block_height,
                    prev_block_id, block_chain_work, block_value_in,
                    block_value_out, block_total_satoshis,
                    block_total_seconds, block_total_ss, block_num_tx,
                    search_block_id
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )""",
                (block_id, store.hashin(b['hash']), store.intin(b['version']),
                 store.hashin(b['hashMerkleRoot']), store.intin(b['nTime']),
                 store.intin(b['nBits']), store.intin(b['nNonce']),
                 b['height'], prev_block_id,
                 store.binin_int(b['chain_work'], WORK_BITS),
                 store.intin(b['value_in']), store.intin(b['value_out']),
                 store.intin(b['satoshis']), store.intin(b['seconds']),
                 store.intin(b['total_ss']),
                 len(b['transactions']), b['search_block_id']))

        except store.dbmodule.DatabaseError:

            if store.commit_bytes == 0:
                # Rollback won't undo any previous changes, since we
                # always commit.
                store.rollback()
                # If the exception is due to another process having
                # inserted the same block, it is okay.
                row = store.selectrow("""
                    SELECT block_id, block_satoshi_seconds
                      FROM block
                     WHERE block_hash = ?""",
                    (store.hashin(b['hash']),))
                if row:
                    store.log.info("Block already inserted; block_id %d unsued",
                                   block_id)
                    b['block_id'] = int(row[0])
                    b['ss'] = None if row[1] is None else int(row[1])
                    store.offer_block_to_chains(b, chain_ids)
                    return

            # This is not an expected error, or our caller may have to
            # rewind a block file.  Let them deal with it.
            raise

        # List the block's transactions in block_tx.
        for tx_pos in xrange(len(b['transactions'])):
            tx = b['transactions'][tx_pos]
            store.sql("""
                INSERT INTO block_tx
                    (block_id, tx_id, tx_pos)
                VALUES (?, ?, ?)""",
                      (block_id, tx['tx_id'], tx_pos))
            store.log.info("block_tx %d %d", block_id, tx['tx_id'])

        if b['height'] is not None:
            store._populate_block_txin(block_id)

            if all_txins_linked or not store._has_unlinked_txins(block_id):
                b['ss_destroyed'] = store._get_block_ss_destroyed(
                    block_id, b['nTime'],
                    map(lambda tx: tx['tx_id'], b['transactions']))
                if ss_created is None or prev_ss is None:
                    b['ss'] = None
                else:
                    b['ss'] = prev_ss + ss_created - b['ss_destroyed']

                store.sql("""
                    UPDATE block
                       SET block_satoshi_seconds = ?,
                           block_ss_destroyed = ?
                     WHERE block_id = ?""",
                          (store.intin(b['ss']),
                           store.intin(b['ss_destroyed']),
                           block_id))
            else:
                b['ss_destroyed'] = None
                b['ss'] = None

        # Store the inverse hashPrev relationship or mark the block as
        # an orphan.
        if prev_block_id:
            store.sql("""
                INSERT INTO block_next (block_id, next_block_id)
                VALUES (?, ?)""", (prev_block_id, block_id))
        elif not is_genesis:
            store.sql("INSERT INTO orphan_block (block_id, block_hashPrev)" +
                      " VALUES (?, ?)", (block_id, store.hashin(b['hashPrev'])))

        for row in store.selectall("""
            SELECT block_id FROM orphan_block WHERE block_hashPrev = ?""",
                                   (store.hashin(b['hash']),)):
            (orphan_id,) = row
            store.sql("UPDATE block SET prev_block_id = ? WHERE block_id = ?",
                      (block_id, orphan_id))
            store.sql("""
                INSERT INTO block_next (block_id, next_block_id)
                VALUES (?, ?)""", (block_id, orphan_id))
            store.sql("DELETE FROM orphan_block WHERE block_id = ?",
                      (orphan_id,))

        # offer_block_to_chains calls adopt_orphans, which propagates
        # block_height and other cumulative data to the blocks
        # attached above.
        store.offer_block_to_chains(b, chain_ids)

        return block_id

    def _populate_block_txin(store, block_id):
        # Create rows in block_txin.  In case of duplicate transactions,
        # choose the one with the lowest block ID.  XXX For consistency,
        # it should be the lowest height instead of block ID.
        for row in store.selectall("""
            SELECT txin.txin_id, MIN(obt.block_id)
              FROM block_tx bt
              JOIN txin ON (txin.tx_id = bt.tx_id)
              JOIN txout ON (txin.txout_id = txout.txout_id)
              JOIN block_tx obt ON (txout.tx_id = obt.tx_id)
              JOIN block ob ON (obt.block_id = ob.block_id)
             WHERE bt.block_id = ?
               ked    block_chain_woIS50) NOT N= ?
          GROUP BYECT txin.txin ?)""", (block']),)):
          in.txin_io, (blockid,) = row
            if stoe._is_descended_from(block_lse io, (block]),']

                store.sql("""
                    INSERT INTO bloIN txrom(block_lin.txin_iounext_block_id)
 s)
                VALUES (?, ?, ?)""",
                          (block_id,.txin_io, (blockime))

    dre._has_unlinked_txiin(store, block_id):
     (t('unlinked_co,)row = store.selectrow("""
            SELECOUNT(1_id)
              FROM block_tx bt
              JOIN txin O= obt.tx_id = txin.tx_ bt
                ON unlinked_txuxin OCT txin.txtx_iduxin.tock_id)
             WHERE bt.block_id  ?)""", (block'])s)

        retut('unlinked_co 1) e))

    dre._get_block_ss_destrorom(store, block_ick_nTimin.txs_id):
        block_ss_destroyed0ID.
        fin.txlsemin.txs,']

         ss_destroyid = in= store.selectrow("""
                SELECOALESCE(SUM(l['txout_app.
# txout_approx_val*"",
                                UES -    b.block_nT)), 0)s)

                  FROM blockws itis)

                  JOIN txin O= ixin.txtx_iOIN txin.tock_id)
                  JOIN txout_appout ON (txin.txout_id ['txout_app.
# txock_id)
 d)
              JOIN block_tx obt ON (txout_appout.tx_id = obt.tx_id)
                  JOIN blok ob ON (obt.block_id= ob.block_id)
  )
             WHEREi bt.block_id     kN (txinock_id = ?""",
                                        UEck_nTimY (block_id, tx_)row[0])
            block_ss_destrod'] ss_destros)

        retur  block_ss_destroe))

 ,

h propagher cumulatiox_vateps    descendur  blatesR  retzes i))

 ,
ed uList tin_longeto_chainont_challining. e    retroddinsactumm))

 ,
isfor  usedist tb, chainame otb, chns,ostiox_idrelat    polib))

 ,
srelsfidatesEattiox_va
is otpatadime blocin_wons,er the block))

 ,
to thlowest blo%s descended frb is in e
# given chked, cin_wock))

 ,
to teckameROM orphin_woID and tin_wobn negivboID ast bltesOnlm))

 ,
en chrows d, chainswoIr tor coder dtesE giv elif ll-known ch))

 ,inont chrob,use thr uLf lif _populsndo a   descendur  bla'))

 ,inr cumulatistrels noocks that  ll-kn    fboID     retsnot amptm))

 ,
dinsactumm.))

    lls adopt_orphock(store,ROM orphin_ws(b, chain_, d, chainswone):          # XXsROMiginnicalwr asis,use thbinnsactiocIn actnicalhre it
       Py win's   nn.cactilicomxin. am   wr aallck, iletmulatlm)it
       ne wimchaecious changehistoose thddisty fileGuidoock)it
      me, picalcrcalunhelpfulehisto   jecaallce givlabe.sdtinopsfig.

        ray  = Npos]
           nelat(x26'):
            rowrayxos]
         doommione:
            storls adopt_orph_1ockllb[0])
     ckllbray   nelat, d, chainsws(b, chain_,ROM orphin_wsre, doom]one
        whickllbone:
         ckllbonf.p)()s)

        retu   rowe))

    drls adopt_orph_1ock(storckllb[:os]
         doommione:
            storls adopt_orph_1ockllb[0])
        def aalurelat(xione:
            storls adopt_orph_2ockllwsrx[0])
        dcanommione:
            ra ckllbonf.p)ne:
         ckllbonf.p)(   ev))

      ra ckllbonf.p)ne:
    ROM orphin_wra ckllbonf.p)ne:
    (b, chain_ra ckllbonf.p)ne:
     d, chainswra ckllbonf.p)ne          fig = {}
     ckllbd'] [    ,dcanom we)D.
        block_i    b['block_iid)
        height = N    if b['heigh[1] is None else iif b['heigh[ht id))

         llssendiIN bloksre nelllif ny  fbelse ON chain_candidrks,)it
       ne   calos in (b, chain_rre.umenmxin.four cad   nn.caatlency,
       inokent(b, chain_lse ON chain_candidhan.
        if (b, chain_one:
  .
        d, chainswone:
  .
 e:
     d, chainswra d, chainswore.invecelat(ne:
  .
 ee
            store.fid, chs_nont_chalload_block(block_)ne:
            chain_idsd, chainsw)))

        f   chainlse    chain_6'):
            r   chainwray(e,ROM orphin_w])))

        for row in store.selectall("""
            SELECn.d, next_block,    b.block_nBitsssssssssssssssssss   b.block_value_o    b.block_value_    b.block_nTimeeeeeeeeeeeeeeeeeee   b.block_total_satosid)
              FROM blod, nECn
                 JOIN blok ob OCn.d, nebt.block_id= ob.block_id)
  )
         WHERn bt.block_id  ?)""", (block'])6'):
         d, nock, ck_nBitck_value_o ck_value_ ck_nTork, satosd,) = row
         ck_nByid = ick_nB_id)
  )
     ck_nTyid = icv_nTime)
         k, satosd,    None if satoshis is None else int(satosh'):
         d,whin_wk'] = util.calculate_woOM orphin_wsrck_nB_id)

               b['chain_workss is None:
             b['chain_wd,    alse
            else:
             b['chain_wd,    b['chain_work+ d,whin_wk-ROM orphin_wid)

            ck_valuekss is None:
             ck_va, ed_co1, ed_co2row = store.selectrow("""
                    SELESUM(   txout.txout_vad']),
                       ECOUNT(1d']),
                       ECOUNT(   txout.txout_vadnds
                      FROM block_tx bt
 )

                  JOIN txin O= obt.tx_id = txin.tx_ bt
                 d)
  LEFT JOIN txoin (   txout.txotx_id = tx
# txock_id)
 d)
 d)
             WHERE bt.block_id  ?)"""d, nock,s']))
                ed_co1rev =d_co2[ht lse:
                 ck_valuekid = ick_vaain)
                else:
                    store.lwarhall(]),
                     "norent upendiIN blo%d ck_valueled:t']ed:[ht ?""",
                     d, nock, rs.r(ed_co1), rs.r(ed_co2_id))
            else:
             ck_valuekid = ick_valueid))
        ) a grcreated = N    ck_valuehis is None else ick_value_o- ck_value_id)

            in(b['secoorkss is None:
             b['secod,    alse
                totald,    alse
            else:
             d,whb['secod, ck_nTy-id, b['nTimne:
             b['secod, in(b['secoork+ d,whb['seco]))
                   b['totalght'] is None or nt(satooorkss is None:
 se
                totald,    alse
                None:
 se
                totald,    b['totaoork+ d,whb['seco * or nt(satooorid)

            ev_satoshis <ID asr nt(satooght'] is not Nght and \
       
            b['satoshht']  <ID ) a grcrean'] is not None:
             ev_satosh'] 1k+    b['satoshht+) a grcreaid)

               heig'] is None    heig'] <                    search_blockd,    alse
            else:
                search_blockd'] = store.get_block_id_at_height(
                    util.get_search_he int(heighlse ick(block_)nd))
            store.sql("""
                UPDATE block
                   SET blrch_he nds = ?,
                  
    block_chain_wnds = ?,
                  
    block_valuends = ?,
                  
    blob['toshi_seconds = ?,
                     b.block_total_satoonds = ?,
                     b.block_totaonds = ?,
x,
                    search_blocknds ock
                 WHERE block_id = ?" ?,
x,
                ght(heig    store.binin_ick_chain_wk'], WORK_BITS                          store.intck_valueITS                          store.inthi_second    store.intal_satooITS                          store.intnt(total_s    search_blockTS                       d, nock_)nd))
         ald,    ald)

               heig'] is not N,']

                store.sql("""
                    UPABLE chain_candid    SET blrch_he yed = ?
                     WHERE block_id = ?""",
                 ght(heig d, nock_)nd))
 e:
            store._populate_block_txin_id, nock_)nd))
 e:
            in(blght'] is Nonenot store._has_unlinked_txid, nock_one:
 se
             passlse
                None:
 se
              xain_ids   (]),
                     ap(lam if r nt(rowTS                        in store.selectall("""
                            SELE xain"""
     ds
                      FROM block"""
      ?
                     WHERE block_id = ?"""d, nock,s'id))
     ]

         ss_destrod'] = store._get_block_ss_destroyed(
                     d, nock_ick_nTimin.txs_ed(
                 ald, in(blghk+    b['satoshhtis ck_nTy-id, b['nTim)and \
       
               ss_destroe))

 ]

                store.sql("""
                        UPDATE block
                           SET block_satoshi_seconds = ?,
                               block_ss_destroyed = ?
                         WHERE block_id = ?""",
                              (store.intal_ss),
 ),
                           store.intss_destro_ss),
 ),
                        d, nock_)nd))
 e:
               strgs.use_firstbits:
         )

        f(pt_addr_ve)row in store.selectall("""
                        SELEc.m, chain_address_vers
    ds
                      FRm, ch c
    bt
 )

                  JBLE chain_candid ccoin (c.m, chack_idcc.m, chack)= ?
                         WHEcc.RE block_id = ?"""d, nock,s':S                        in stodoess_vuse_firstb(pt_addr_ve in_id, nock_)nd))
 e:
     nbock =                "RE block": d, nock_=                "ht(hei": ht(hei_=                "ck_chain_w": ck_chain_w_=                "b['nT": b['nT_=                "hi_seco": hi_seco_=                "ck_satoo": hk_satoo_=                "nt(total": nt(totao_=                "co": hs}nd))
 {}
     ckllbd'] [   ,def aalurelat_=               :
     d, chainswone, Nond,whin_wonde, doomwe))

    drls adopt_orph_2ock(storckllbg d, no   ':S           ra ckllbonf.p)ne:
        f   chainlse    fig.keys():
         patad= d, no   r   chainwd)

            patadn_c patarow[>    r   chainwrows():
                r   chainwra patae))

    dran orxout_scriptPubock(stor
# tx,ven chkeut_scriptPubys():         "nr
# tx,vseteut_scr_he torin_address_versiore.in_aked,     fON multi, re_sirinkltinatuadd.   '])

       eut_scriptPubkss is None:
 se
     
# tx['ut_scr_he t'ss'] = Noe:
 se
     
# tx['re.in_a'ss'] = Noe:
 se
     
# tx['in_address_vers'ss'] = Noe:
 se
        return

    eut_scr_he torve dav == chae, s.u   txout_scr(ut_scriptPuby
se
     
# tx['ut_scr_he t'ss'eut_scr_he t
se
     
# tx['in_address_vers'ss']in(chain.address_vers'])

       eut_scr_he t =in = ChaAX_SCREMA_TULL_PUB:oe:
 se
     
# tx['re.in_a'sav == chae, pubkey_h(ve did))
         eut_scr_he t =in = ChaAX_SCREMA_TUADDRESS:oe:
 se
     
# tx['re.in_a'sav ve dd))
         eut_scr_he t =in = ChaAX_SCREMA_TUP2SH:oe:
 se
     
# tx['in_address_vers'ss']in(chain.script_addr_voe:
 se
     
# tx['re.in_a'sav ve dd))
         eut_scr_he t =in = ChaAX_SCREMA_TU
# MUSONFIG:
 se
     
# tx['re_sirinkltinatuadd'sav ve d['morie:
 se
     
# tx['re.in_a'sav == chae, pubkey_h(ut_scriptPuby
se
 se
     
# tx['uubre.in_a'sav ock[
             == chae, pubkey_h(e, puby
se      )

        fe, publse ve d['e, pubd's
se      )

     ]d))
         eut_scr_he t =in = ChaAX_SCREMA_TUBURN:oe:
 se
     
# tx['re.in_a'sav in(NULL_PUBKEY_Hoe:
 se
 ")
# MULTICHAIN STd))
         eut_scr_he t =in = ChaAX_SCREMA_TU
# MULTICN:oe:
 se
     
# tx['re.in_a'sav ve dd))
         eut_scr_he t =in = ChaAX_SCREMA_TU
# MULTICNUP2SH:oe:
 se
     
# tx['in_address_vers'ss']in(chain.script_addr_voe:
 se
     
# tx['re.in_a'sav ve dd))
         eut_scr_he t =in = ChaAX_SCREMA_TU
# MULTICNUENTITY_PERMISVERN:oe:
 se
     
# tx['re.in_a'sav ve d tx.gee, pubkey_hicy')
     ))
# MULTICHAIN E           N:oe:
 se
     
# tx['re.in_a'sav  = Ne))

    dex import_block(store, chain=N_id, block_hain=N_id, blonuememain=Nys():         ():     sR  retza
dinsone with tfolhe endne):       *BLE chain_candids[]d))
         *BLE chd))
         *Bchain_long):       *BLE chahk_satoo):       *BLE chack_satoshi_seco):       *BLE chhin_w):       *Bfeeo):       *B a grcreai:       *Bck_hi:       *Bck_hashMerkleRi:       *Bck_hashPi:       * ht(heii:       *rck_no):       *Bd, nod, block_heo):       *Bb['nNo):       * b['no):       * hk_satoo_ss_destro):       * hk_satoshi_seco):       *ate transacts[]d))
         *Bfeeo):   :       *Bck_hd))
         *Bch[]d))
             *Bin_address_vers
 )
             *Bre.in_a
 )
             *] = value
         *] tx[]d))
             *Bin_address_vers
 )
             *Bre.in_a
 )
             *] = value
         *]sizo):       *tck_value_):       *tss_vers'])

     Adnomactnica,    fON multiBchputsed,  ue_putsne):       *Buubre.in_a[]d:       *Bre_sirinkltinatuadd'])

     Adnomactnica,   ther of-of-cklk (b, chsne):       *Boo_er of_of_cklk ):       *Ber of_of_cklk _ a grcreai:          '])

       id, blonuememBoonot Nght ad, block_hBoonot N= 1:
            raipt ValueEr("ex import_blBre_siris eid othd, block_hBorid, blonuemem(1)")

    ns,er t= []d:       re.dt= []_id

        if chain is not None:
         s,er ray.appe'if chock_id icy')
         re.dray.appet([chain)'])

       id, block_hain is not None:
         s,er ray.appe'd, block_h_id icy')
         re.dray.app   (store.hasrchx(d, block_h))'])

       id, blonuememain is not None:
         s,er ray.appe'd, bloct(hei_id     kchain_long_id1icy')
         re.dray.app d, blonuemem)'])

     re._idll("""
            SELn (
                chain_n (
             chain_long_n (
             ch_blockTS                d, block_hTS                d, bloss_versTS               on, block_hashMerkleRoot,
              b.block_nTimeeeeeeeeeeeeeeee b.block_nBitsssssssssssssssts, block_nNoitsssssssssssssssce, block_height,
                prd, block_hTS                d, block_chain_w_=               rk, block_value_in,
              b.block_value_o
                 b.block_total_satoo,
              
    blob['toshi_seco,
                   block_satoshi_secon
              
    blob['toshon
                   block_ss_destron
               ss, block_numid)
              FRl['chain_summid)
  )
         WHEll(k+ '    k' "".jos,er )k+ ll("""
          ORDER BYn (
             chain_long DESC,n (
                chain DESCll("""
     te ro= in store.selectare.iore.n)'])

           lte rnt() == 0:
            return Noh):
        ro te rrow[2:pos]
         e, s.ucclte ys(               chain_ chain_long o te [:2] 0:
            retu{ "ck_ch":] = store.gck_chmitainin (chain_, "chain_long":]chain_long }d))

       Absenm in (b, chrre.umenm,    aN meps h_heong    chain_    ped endepscan avocode    cphans.
     ccids   (e, s.ucc, te rnd))

       "ck_ch"ler mbelin=N_idutlseou.fid, ch" nelllif ans.
     eou.fid, chs']in(ch])

        eou.fid, chsoonot N= 1:
               lcc, 1) > 0:
       
     eou.fid, chs']icrowin ['cha]lse
            else:
             #XXX Shouif uifrmnica we g,er r 0:
       
     eou.fid, chs'] = store.g   aN mid, chack()

     (   block_id, block_hash, block_versiock_hashMerkleRoot,
      ck_nT, ck_nBitck_nNoi ht(hei_=            prd, block_hT d, block_chain_wo ck_value_ ck_value_o
        rk, satoshis, secondsondck_total_sss_destron ck_numime) = (
         nt(row_id, store.hue_rchx(nt(row[, nt(r2wTS           id, store.hue_rchx(nt(r3w[, nt(r4w_ise int(r5w[, nt(r6wTS            nt(r7w_id, store.hue_rchx(nt(r8ed']),
            store.binout_(nt(r9ed'lse int(ro0ed'lse int(ro1ed']),
        ] = None if ro2w[1] is None else int(ro2ed']),
        ] = None if ro3w[1] is None else inf ro3ed']),
        ] = None if ro4w[1] is None else inf ro4ed']),
        ] = None if ro5w[1] is None else inf ro5ed']),
        ] = None if ro6w[1] is None else inf ro6wd']),
        lse inf ro7wd']),
        lck()

    Bd, nock_heoav ock[
         d, store.hue_rchx(ck_h)   thck_hT illse
            in store.selectall("""
            SELEDISTINELEn.d, block_hT cc.chain_longid)
              FROM blod, nECn
                 JOIN blon ob OCn.d, nebt.block_idn ob.block_i                 JBLE chain_candid ccoin (n ob.blocks']ic ob.block_id)
  )
         WHERn bt.block_id """
          ORDER BY cc.chain_long DESC= ?""",
                         ", (block']) we)D        xain_i= []_D        xsfig = {}
     , (bloue_yed0ID.
     , (blocnyed0)))

        for row in store.selectall("""
            SELE xainh'], tx_hh'], sizoh']t.txout_vah']t.txout_scriptPubid)
              F']t.txodet_clid)
  )
         WHEbt.block_id """
          ORDER BY ], tx_h']t.txotx_"""
      ?)""", (block'])6'):
        E xainh'], tx_hh'], sizoh']t.txout_vah'ut_scriptPubme) = (
  (
         nt(row_int(row, nt(r2w_ise int(r3w[,    store.binint(r4ed))):
            tx xs tx.g xain)se

            ifsoonot N= 1:
     D        xain_ray.appg xain)se

              xs[ xain]ock =             "
      on ha: d, store.hue_rchx(], tx_hd']),
                 "nt(totue_a: 0']),
                 "nt(toocna: 0']),
                 "ue_a: []']),
                 "cna: []']),
                 "sizoa: se i], sizod']),
                 = {}
 ):
            tx xs[ xain]'])
            txt(tooue_out'] +t.txout_va'])
 {}
     , (bloue_t'] +t.txout_va'oe:
 se
     
# txock  'ut_va': +t.txout_va =             in storan orxout_scriptPubo+t.tx, eou.fid, chkeut_scriptPuby'])
            tue_ouray.appg xue_])))

        for row in store.selectall("""
            SELE xainh'],inout_vah'],inout_scriptPubid)
              F']tinodet_clid)
  )
         WHEbt.block_id """
          ORDER BY ], tx_h']tinotx_"""
      ?)""", (block'])6'):
        E xainh'],inout_vah'ut_scriptPubme) = (
  (
         nt(row_i0one if row[1] is None else int(row[']),
                store.binint(r2ed))):
            tx xs tx.g xain)se

            ifsoonot N= 1:
     D          #n xra,Bchputsidutlno ue_puts? 1:
     D        xain_ray.appg xain)se

              x tx_hh'], sizorow = store.selectrow("""
                    SELE x tx_hh'], sizor   F']t    WHEinock_id = ?""",
                                        g xock'])se

              xs[ xain]ock =             "
      on ha: d, store.hue_rchx(], tx_hd']),
                 "nt(totue_a: 0']),
                 "nt(toocna: 0']),
                 "ue_a: []']),
                 "cna: []']),
                 "sizoa: se i], sizod']),
                 = {}
 ):
            tx xs[ xain]'])
            txt(tooue_in'] ],inout_va'])
 D.
     , (blocny'] ],inout_va''])
 D.
     ],inock  'ut_va': ],inout_va =             in storan orxout_scriptPubo+tin, eou.fid, chkeut_scriptPuby'])
            tue_iray.appg xue_id       ) a grcreated, (bloue_t- , (blocnns.
     c".jatab_   tx xs[ xainrrow]ns.
     c".jatab_   tfedd'saed0ID.
     , (blofeddaedc".jatab_   txt(tooue_out-) a grcreaid)

     bock =            'LE chain_candids':      cc,=            'LE chack_satos':       rk, satosh=            'LE chack_satoshi_seco': nt(totao_=             b['chain_wo:            d, block_chain_w_=            tfeddo:          D.
     , (blofedd_=            t a grcreao:          D.) a grcrea_=            ttx_ho:                  d, block_hTS            (b['hashMerkleRo:        ck_hashMerkleRoot,
         (b['hashPr:
                prd, block_hTS               'heighttttttttttttttt    height,
          ck_nBo:                 ck_nBght,
          d, nod, block_heoo:    Bd, nock_heBght,
          dk_nNoo:                ck_nNoitssssssssssss b['nTi:                 b['nTitssssssssssss hk_satoo_ss_destroi:    ss_destroitssssssssssss hk_satoshi_seco':sssssssao_=             te transactsi:          [ xs[ xain]    fin.txlsemin.txs]']),
         (b['value_i: ])
 {}
     , (bloue_']),
         (ss_vers':               d, bloss_versTS            }d))

     oo_cklk id, chs']in(cht'] is not Nght ain(chore.ofeatuad('nvc_er of_of_cklk '),))
        oo_cklk id, chone:
           Pr of-of-cklk (displr mbassdtinos calos CryptoManiac/novac".jght ne:
           http://nvc.cryptoc".jan l strore.ans.
            oo_er of_of_cklk 'sae    lin.txs, 1)1ght ac".jatab_   txt(tooue_out=ed0)))

        fin.txlsemin.txs[1:ws():
            tx xs[ xain]'])
            tfedd'sae    txt(tooue_in-    txt(tooue_ou
,))
        oo_cklk id, chght a   oo_er of_of_cklk 'slse:
            er of_of_cklk _ a grcrea'sae - xs[ xainrrow] tfedd'sse:
          xs[ xainrrow] tfedd'saed0ID.
           tfedd_in']    er of_of_cklk _ a grcrea'sds)

        reture))

    dre.tx_find_id_and_vaock(stor
#, oo_c".jatatore,eblounlm= = Faash):
        row = store.selectrow("""
            SELEtpout.tx,ESUM(   txout.txout_vad'ESUM("",
                    CASE    JOIN txae, pub.tx 1)  T  JOIN txa+t.txout_va'])
 {}}}}}}}}}}}}}}}}}}}}}}}ELSE 0AIN )id)
              F']t
            d)
  LEFT JOIN txoin (  a+tout_id = txoutock_id)
  )
         WHEutock_h_id = ?
          GROUP BYE  a+tout= ?""",
                              (store.hasend(tx['hashsh),))
        if = 1:
            e,eblounlm= 11:
     D         Drs'rent uper
#, to ss aw =upemenm s,ense, awd cat  oo 11:
     D         s,ene g fin.txlssrow in st 11:
     )

        ret nt(row
'):
        E xainitck_value_o unss_destrod,) = row
        tck_value_d,)0one ck_value_dis is None else ick_value__id)
  )
     unss_destrod,)0one unss_destrodis is None else iunss_destro_id)
  )
     ed_colue_ ck_valuerow = store.selectrow("""
                SELECOUNT(1d'ESUM(   p txout.txout_vadnds
                  F']tinid)
                  JOIN tx    p txout ON (txin.txout_id   p txout.txock_id)
  )
             WHEN (txinock_id = ?" g xock'])se

            (ed_colueBori0) <    lx: tx[Ie_inlse:
             ck_valuekid0one oo_c".jataNone e] = Noe:
 se
     += tx['value_ited = N    ck_valuehis is None else ick_value_oe:
 se
     += tx['vaoue_out= ck_value_oe:
 se
     += tb['value_destroyed']ck_value_o- unss_destro 0:
            retu xockds)

        retu = Ne))

    dre.import_ck(stor
#, oo_c".jatatord, chnlse:
     inock_idnt(store.new_itx"_oe:
 se
 dbck_h_id  (store.hasend(tx['hasnd))

      prse  "re.import:g =".ffrmnt(   utin_lrchx(nd(tx['has[::-1ns']))
             ,))
        'sizoash' not in tx:
  e
     += 'sizo'sae    ash(tx['__data__']           store.sql("""
            INSERT IN   ( xainh'], tx_hh'],oss_versh'],o, bl['nTi'], sizo']))
            VALUES (?, S (?, ?, ?)""",
               ( xainh dbck_hd    store.in( xn(b['version']),
                   store.in( xn(, bl['nTion' += 'sizo'ns'e):

        # Impote transact ue_puts.se:
     in  b['value_out'] =se
     += tb['value_destroyed']0ue

        for pos in xran   lx: tx[Oe_ou])6'):
        E xue_d,)x: tx[Oe_ons'][poe:
 se
     += tx['vaoue_out'] +t.tx tx['vaorie:
 se
     
# txock_idnt(store.new_i
# tx"_oie:
 se
     e, pub.tk_idnt(stout_scr_ho_e, putainin (ch, +t.tx tut_scriptPubime'])
            e, pub.tkt'] is not Nght ae, pub.tkt<) == 0:
 e:
 se
     += tb['value_destroyed'] +t.tx tx['vaornd))
            store.sql("""
                INSERT IN xue_d("",
                  xue_ock_id, txh']t.txotx_h']t.txout_vah"",
                  xue_out_scriptPub,ae, pub.tk"",
             )    VALUES (S (?, S (?, ?, ?)""",
                   ( xue_ock_id, txh'tx_h'   store.in( x.tx tx['vaion']),
                       store.bi(+t.tx tut_scriptPubime,ae, pub.tks']))
 )

        for row in store.selectall("""
                SELut('unlinkIN txin.toinh'], tx_hh']tinotx_"""
                  F't('unlinkIN t)
  LEFT JOIN txin Ot('unlinkIN txin.txtx_iOIN txin.tock_)
  LEFT JOINxin ON (txin.tx_id  a+tock_id)
  )
             WHENxue_outock_h_id = ?
                   ']t.txotx__id = ?" gdbck_hd tx_])6'):
   
          in.txin_is.apperock_h_is.apperonid,) = row
       
      prse  "U('unlin: sdg =g =, =g->g =, =gde.ste".ffrmnt in.txin_i   utin_lrchx(nd(tx['has[::-1nsd tx__id, store.hue_rchx(s.apperock_h)_is.apperoni]),
                stos.ap_out.txoassets(nd(tx['hasd tx_ord, ch_id, store.hue_(s.apperock_h)_is.apperoni ))
# MULTICH   ssdunsoassetd aae.itie] isw    ed_lds'retx_ouldf st 11:
     )

       store.sql("UPDOIN t    Sut.txock_id = ? WHOIN tock_id = ?",
 ",
                   ( xue_ock_id,iphan_id))
 ))
            store.sql("DELETE FRt('unlinkIN t= ? WHOIN tock_id = ?",
 ",
                   ( xiphan_id,)")
# MULTICHAIN STy')
         re.ut_scr_id   store.bini+t.tx tut_scriptPubime'])
         ut_scr_he torve dav == chae, s.u   txout_scr(re.ut_scre'])
            e, pub.tkt'] is not Nght aut_scr_he else [ = ChaAX_SCREMA_TU
# MULTICN,n = ChaAX_SCREMA_TU
# MULTICNUP2SHws():
            rve dav    util.gON muck_chaop_drop_ve d(re.ut_scre'])
  )
           rve dain is not None:

















opdrop_he to]ck_av    ute, s.aop_drop_ve d(ve d= 0, chain)
 ])
  )
           
opdrop_he t==   utOP_DROP_MA_TUISVUTUAS   one:













v

        (fi#, )row =runs.unpllba"<H"h dbck_h[0:2__'])

                        row = store.selectrow("""
                             SELuassetock_id FRasset= ? WHOasset.  (fi#yed = ?
                           ?)"""  (fi#'])se

                        if soonot N= ,
to tusual In cse

           
             d,whassetock_idnt(store.new_iasset")se

         ]

                store.sql("""
                                INSERT IRasset=(assetock_id, txh'   chain_ nanTi'ON mu duer, oosvalqtb,a  (fi#)"""
                                VALUES (S (S (?, S (?, ?, ?)""",
                   

v

      d,whassetock_id, txh'   ch.txh    store.bisql), 0o]ck_,a  (fi# ])se

                     ne N= ,
   wd at ent upendia cklf-acnn.Creati_srdse

           
             d,whassetock_idnt(rowse

         ]

                store.sql("""
                             l("UPDOasset    Sinock_id , oosvalqtbyed = ?
                                WHEassetockyed = ?
                              ?)""",
                   

v

       xainitck_, d,whassetocks'e):       ]

                stont upehassetoin_addrebalanNo d,whassetock,ae, pubainitck_, nd(tx['hasn;

        ]

                store.sql("""
                            INSERT IRassetkIN d=(assetock_id, txh']t.txotx_)
                               VALUES (S (S, ?)""",
                   

v

  d,whassetock_id, txh'tx_pos))
     ow
       
       +t.tx tut_scriptPubimBor re.ut_scrtin_wetx_eg,er s))
     ow
       
    tss_vs']in(chain_address_vers
    ds
                 to _ut_scr_he tore, pubkey_hav == chae, s.u   txout_scni+t.tx tut_scriptPubime'])
                     e,eblin_s']in(chain_addree,eblin_se

                        e,eblin_soonot N= 1:
                         in_addrav    utey_h_ho_in_addr(ss_vore, pubkey_he'])
         se
            else:
                         in_addrav    utey_h_ho_in_addrgON muck_ch(ss_vore, pubkey_h, e,eblin_e'])
         se
   
      prse  "NewRasset oosvaield in_addr:g =, balanNog =".ffrmnt(in_addritck_e']       se
             
opdrop_he t==   utOP_DROP_MA_TUSIN UAS   Bor opdrop_he t==   utOP_DROP_MA_TUISVUTUMORTUAS   one:













v

     msge, p_i= []_D               )

        fdinsointck_lse:
                        d aae.itbyeddinx t aae.itb'wse

         ]

             asset (fyeddinx tasset (f'wse

         ]

                e, chaerotoc"less_vers < 10007:"",
                   

v

       (fi#yelse i asset (f.s du.ge-')[-1n e']   ])
         se
            else:
                                (fi#, )row =runs.unpllba"<H"h re.iscii.unchx   y(asset (f)[0:2__'])

 ))
     ow
       
    tss_vs']in(chain_address_vers
    ds
                     to _ut_scr_he tore, pubkey_hav == chae, s.u   txout_scni+t.tx tut_scriptPubime'])
                         e,eblin_s']in(chain_addree,eblin_se

                            e,eblin_soonot N= 1:
                             in_addrav    utey_h_ho_in_addr(ss_vore, pubkey_he'])
         se
                else:
                             in_addrav    utey_h_ho_in_addrgON muck_ch(ss_vore, pubkey_h, e,eblin_e'])
         se
   
         se

         ]

             asset tx=   st.  (fi#_ho_assetnd_or_d,w   (fi#, ck_ch)se

         ]

                stont upehassetoin_addrebalanNo assetock,ae, pubainit aae.itb, nd(tx['hasn;

        ]

                    store.sql("""
                                INSERT IRassetkIN d=(assetock_id, txh']t.txotx_)
                                   VALUES ?,S, ?)""",
                   

v

  assetock_id, txh'tx_pos))
     ow
       
         ']       se
             
opdrop_he t==   utOP_DROP_MA_TUPERMISVERN:'])
         se
   
      prse  'Permisversways cht adetexpec''])
         se
         passlse
              e, pub.tkt'] ot Nght aut_scr_he elssn = ChaAX_SCREMA_TU
# MULTICNUOP_RETURN:oe:
 se
 







op   ret_he to]ck_av    ute, s.aop_   ret_ve d(ve d= 0, chain)
 ])
  )
     # Exte nsocht a  sy met_ve dght ant upeRasset c"lumnin)
 ])
  )
     # Legaolierotoc"l 10006'])
  )
           rop   ret_he t==   utOP_RETURN_MA_TUISVUTUAS   one:













v

    store.sql("""
                     l("UPDOassetock
                            nanT_id ,'ON mu dueryed = ?
                         WHEtxockyed = ?
                       ?)""Ot(icodeick_['nanTasd 'lupen-1'), ck_['ON mu duerasdid, tx_)ne:













v

    store.sql("""
                    INSERT IRassetkIN d=(assetock_id, txh']t.txotx_)
                       VALUE (   SELuassetock_id FRasset= ? WHOd, ck_id      nanT_id )  (S (S, ?)""",
                   xainitt(icodeick_['nanTasd 'lupen-1'), d, txh'tx_polse
              e, pub.tkt'] ot Nght aut_scr_he elssn = ChaAX_SCREMA_TU
# MULTICNUSPKN:oe:
 se
 





    Protoc"l 10007oe:
 se
 







opdrop_he to]ck_av    ute, s.aop_drop_ve d(ve d= 0, chain)
 ])
  )
       
opdrop_he t==   utOP_DROP_MA_TUSPKN_NEWUISVUTone:













v

    store.sql("""
                      l("UPDOassetock
                             nanT_id ,'ON mu dueryed = ?
                          WHEtxockyed = ?
                        ?)""Ot(icodeick_ tx.geAsset=NanTa,'')d 'lupen-1'), ck_ tx.geQaae.itbyMN mu dTa,1)did, tx_)ne:













v

    store.sql("""
                         INSERT IRassetkIN d=(assetock_id, txh']t.txotx_)
                            VALUE (   SELuassetock_id FRasset= ? WHOd, ck_id      nanT_id )  (S (S, ?)""",
                        xainitt(icodeick_ tx.geAsset=NanTa,'')d 'lupen-1'), d, txh'tx_pol
))
# MULTICHAIN E):

        # Impote transact inputs.se:
     in  b['valinout'] =se
     += tt('unlinked_coyed']0ue

        for pos in xran   lx: tx[Inou])6'])
 D.
     ],inockx: tx[Inous'][p'])
 D.
     ],inock_idnt(store.new_i
,in"_oie:
 se
     ne oo_c".jataNone:













]t.txockd,    alse
            else:
             ]t.txainitck_va_idnt(stoinokup_]t.tx("",
                  xch['   p tx_x['hasd  xch['   p tx_nouain)
 ])
  )
       
ck_vasoonot N= 1:
                 in  b['valinoud,    alse  se
              in  b['valinouain is not None:

















in  b['valinoed'] b['vand))
            store.sql("""
                INSERT IN xino("",
                  xchock_id, txh']tinotx_, ]t.txainll(k+ ( ?)""",
                '],inout_scrSti,'],inoue_sisto ?)       strkeepout_scrlti
                                                 se
            e  ?)k+ ll("",
             )    VALUES (S (?, Sll(k+ (  (?, S)       strkeepout_scrlti
                                              e  ?)k+ ll(, ?)""",
                   ( xchock_id, txh'tx_, ]t.txain']),
                       store.bi(+tch['ut_scrStiion']),
                       stose bi(+tch['ue_sistoou])       strkeepout_scrlti
                         e ( xchock_id, txh'tx_, ]t.tx tx_)ne:









ne:






      if (oo_c".jataNght  ]t.tx txsoonot N= 1:
     se
     += tt('unlinked_coyeh'] 1']

                store.sql("""
                    INSERT INt('unlink xino("",
                      xchock_ENxue_outock_hh']t.txotx_"""
 ",
             )    VALUES (S (?, ?= ?",
 ",
                   ( xiphan_d  (store.hase xch['   p tx_x['hion']),
 ),
                       stose bi(+tch['   p tx_noua))row
       
      prse  "U('unlin: sdg =g =, =g->g =, =ge.uert".ffrmnt in.txin_row
       
         i   utin_lrchx(ndch['   p tx_x['his[::-1nsd +tch['   p tx_nou_i   utin_lrchx(nd(tx['has[::-1nsd tx_d,)")
# MULTICHAIN STy')
            ]t.tx txg'] is not N,']

                stor.ap_out.txoassets( xch['   p tx_x['hasd  xch['   p tx_nouord, ch_ind(tx['hasd tx_d,))
# MULTICHAIN E):

        # XC Shoue._popul LL_PUB.LL_PUBone wi xinout_scrl...):

         fleo scks teld in  # 'uneierocddr. notthasiBchuse tierogram):

      Bre_siris to .ans.         retu xock,)")
# MULTICHAIN STy')
    dr.ap_out.txoassets_ck(stor   p tx_x['hor   p tx_nord, ch_is.apperock_h_is.apperoni,']

     re.ut_scrtidnt(stoinokup_]t txout_scne, pub(   p tx_x['hor   p tx_n'e):

      if re.ut_scrsoonot N= 1:
         iprse  "U('unlin eueEr: ck_hg =gp txg =".ffrmnt(   utin_lrchx(   p tx_x['h[::-1nsd t  p tx_n'e 






ne:





if re.ut_scrg'] is not N,']

         r.ap_out_ck_h_id  (store.h tx(   p tx_x['h)      Bress_ve ue_o ttherwive irg'] bllbwarco):     
    tss_vs']in(chain_address_vers
    ds
     the_ut_scr_he torve dav == chae, s.u   txout_scr(re.ut_scre      Bve dain usualldist re, pubkey_hidutlc Shoubeddinxoie:
 se
     ne the_ut_scr_he elssn = ChaAX_SCREMA_TU
# MULTICNUENTITY_PERMISVERN:oe:
 sssssssssssre, pubkey_hiv ve d['e, pubkey_ha]lse
            else:
             e, pubkey_hiv ve doie:
 se
     ne the_ut_scr_he elssn = ChaAX_SCREMA_TU
# MULTICNUP2SH:oe:
 se
        tss_vs']in(chain.script_addr_voe:
 se
     e,eblin_s']in(chain_addree,eblin_se

            e,eblin_soonot N= 1:
             in_addrav    utey_h_ho_in_addr(ss_vore, pubkey_he'])
            N= 1:
             in_addrav    utey_h_ho_in_addrgON muck_ch(ss_vore, pubkey_h, e,eblin_e'])
         e, pub.tk_idnt(stoe, pubkey_h_ho_ew_e, pubkey_h, 0)oie:
 se
     ne the_ut_scr_he else [ = ChaAX_SCREMA_TU
# MULTICN,n = ChaAX_SCREMA_TU
# MULTICNUP2SHws():
            rve dav    util.gON muck_chaop_drop_ve d(re.ut_scre'])
  )
           rve dain is not None:

















opdrop_he to]ck_av    ute, s.aop_drop_ve d(ve d= 0, chain)
 ])
  )
  )
       
opdrop_he t==   utOP_DROP_MA_TUISVUTUAS   one:













v

        (fi#, )row =runs.unpllba"<H"h r.ap_out_ck_h[0:2__'e:













v

     'e:













        asset tx=   st.  (fi#_ho_assetnd_or_d,w   (fi#, ck_ch)se

         ]

            stont upehassetoin_addrebalanNo assetock,ae, pubainit-ck__is.apperock_h)
']       se
             
opdrop_he tlse [   utOP_DROP_MA_TUSIN UAS   ,    utOP_DROP_MA_TUISVUTUMORTUAS   ws():
               
       S.apsendisenm ix    oosva m st ix_D               )

        fdinsointck_lse:
                        d aae.itbyeddinx t aae.itb'wse

         ]

             asset (fyeddinx tasset (f'wse

         ]

                e, chaerotoc"less_vers < 10007:"",
                   

v

       (fi#yelse i asset (f.s du.ge-')[-1n e']   ])
         se
            else:
                                (fi#, )row =runs.unpllba"<H"h re.iscii.unchx   y(asset (f)[0:2__'e:
                                 lIN d=begchro5484...ist r  (fifsoon0x8454lse vecaeci.'e:
                               x-y-zzzz ns,er tzzzz = 33876
se

         ]

             asset tx=   st.  (fi#_ho_assetnd_or_d,w   (fi#, ck_ch)se

         ]

                stont upehassetoin_addrebalanNo assetock,ae, pubainit- aae.itb_is.apperock_h)
']       se
             
opdrop_he t==   utOP_DROP_MA_TUPERMISVERN:'])
         se
   
      prse  'S.apsendlINone wiPermisversways chtc''])
         se
         passlse
                     y')
    d  (fi#_ho_assetnd_or_d,w ck(stor   fi#, ck_chash):
        row = store.selectrow("""
             SELuassetock_id FRasset= ? WHOasset.  (fi#yed = ?
           ?)"""  (fi#'])se          if soonot N= ,
   wd il.Nt('uckyght  se ways esuldf stRasset oosvanNo,'Olk ia cklf-acnn.Creati_srdcks te want uped opula
 )
         assetock_idnt(store.new_iasset")se

            store.sql("""
                INSERT INasset=(assetock_id, txh'   chain_ nanTi'ON mu duer, oosvalqtb,a  (fi#)"""
                VALUES (S (S (?, S (?, ?, ?)""",
             (assetock_i1h'   ch.txh    store.bisql), 0o]0,a  (fi# ]) ,
flk  m sretxeld ck_vasE           N:oe:
 se
     assetock_idnt(rowse

        ret assetock
    y')
    dnt upehassetoin_addrebalanNo ck(storassetock,ae, pubainit aae.itb, ndock_h):]           store.sql("""
            INSEOR IGNORTERT INassetoin_addrebalanNo  assetock,ae, pubainitbalanNo)"""
            VALUES ?,0, ?)""",
      assetock,ae, pubain))]           store.sql("""
         l("UPDOassetoin_addrebalanNo"""
                balanNo = balanNo +d = ?
           ? WHae, pubaik_id      assetock_i = ?
           ?)""" aae.itb, e, pubainitassetocks'))

      prse  "BAL:g = e, pubg = ck_g =".ffrmnt(   utin_lrchx(nd_x['h[::-1nsd t, pubainit aae.itb) e 






n))
# MULTICHAIN E    ))

    dre.imp_id_ays ciport_ck(stor
#, oo_c".jatatord, chnlse:
     irylse:
         inock_idnt(store.import_
#, oo_c".jatatord, ch)se

            stoys cipack()

     except    stodbmodule.De datatEueEr:se

            storolhbllba)ne:
           Violasact uf ndock_htt(i_sisddr?se:
         inock_idnt(store.tx_find_id_and_va_
#, oo_c".jatat)ne:






      if (inock:se

                ra
ns.         retu xock,))

    der be_re.impore.iryort_ck(sto'   chananTi're.iryortnls




     '   chananasoonot N= 1:
         d, chs'] = store.g   aN mid, chack           N= 1:
         d, chs'] = store.gck_chmitanana(   chanana)e)D        xkey_hav == chate transactkey_h(re.iryortne)D       (ed_co,)row = store.selectr 1:
         "   SELECOUNT(1dr   F']t    WHEinkey_h_id = ?",
 ",
        (store.has(], tx_hd'))'])

       ied_cot() == 0:
        Einav == chae, s.u e transact(re.iryortn 0:
        End(tx['hasav ], tx_h 0:
        dnt(store.import_
#, == chaoo_c".jatatort_
#)ord, ch)se:
        dnt(store.impedmittes(+= 'sizo'nse))

    dex import_ck(sto' xockain=N_ ], tx_hain=N_ vecaecis=8, ffrmnt="api"ord, chain=Nys():         R  retza
dinsoasiseetury /rawix   not N    if (eou.f.   ']          TODO: merge _ex importodet_clone wdex import.])

       iffrmnot() 'bectuer'= 0:
            retdnt(sto_ex importodet_cl(], tx_hord, chad, ch)e)D        xfig = {}
     oo_bchs']ffrmnot() "re.iry ']           ]t txg'] is not N,']

 ):
        row = store.selectrow("""
                SEL'], tx_hh'],oss_versh'],o, bl['nTi'], sizo"""
                  F']t
                    WHEtxockyed = ?
         = ?" g xock'])se

            if soonot N=se

      

        retu = N 0:
        End(tx['hasav d, store.hue_rchx(nt(r0nse))            in tx_hg'] is not N,']

 ):
        row = store.selectrow("""
                SEL'], idh'],oss_versh'],o, bl['nTi'], sizo"""
                  F']t
                    WHEtxotx_hged = ?
         = ?"    (store.hasrchx(], tx_hd'])se

            if soonot N=se

      

        retu = N 0:
        End(tx['hasav ], tx_h.decodei'chx')[::-1n    oo_bch    N ], tx_hse:
         inock_i nt(row
'):
        N= 1:
            raipt ValueEr("ex impotxBre_siris eid othinock_or ], tx_h."_oie:
 se
  xn(b['versi    oo_bch    N (b['asaaaaaaaa=lse int(row[ie:
 se
  xn(, bl['nTi    oo_bch    N (  blob'nTioa=lse int(r2__'ee
     += 'sizo'sae se int(r3w_oie:
 se
  xin_i= []_D        x tx[Isi    oo_bch    N (inoud,  xin_))

        for row in store.selectall("""
            SELse

      

     COALESCE(  a+, tx_h,    out.txo], tx_hd'se

      

     COALESCE(ut.tx.]t.txotx_h    o]t.txotx_)ll(k+ ( ?)""",
            '],inout_scrSti""",
            '],inoue_sisto ?)       strkeepout_scrlti    e  ?)k+ ll("",
            F']tinid)
       d)
  LEFT JOIN txout ON (txin.txout_iOIN txout.txock_id)
  )
     
  LEFT JOINxin ONN txoin.tx_id  a+tock_id)
  )
     
  LEFT JOt('unlink xino   out ON (tx],inock_id   x],inock_id)
  )
        WHEN (txinock_id id)
  )
     ORDER BY N (tx],inotx_= ?" g xock'])= 1:
        r   p tx_x['h_i nt(row
1:
        r   p tx_nd,    aone if row[1] is None else int(row[
1:
            oo_bch:"",
            '],inock =             "
     '   p tx_x['ha:d  (store.h tx(   p tx_x['h),=             "
     '   p tx_s':r   p tx_n}'])
            N= 1:
                   p tx_x['hsoonot N=se

      

            pr txock =             "
         ttx_ho: "0" *B64,     # XsX Shod  (st se w?=             "
         ts':n0xffffffff}      # XsX Shod  (st se w?=             "
    N=se

      

            pr txock =             "
         ttx_ho: d, store.hue_rchx(   p tx_x['h),=             "
         ts':r   p tx_n}'])
            '],inock '   pr tx':r   pr tx}'])
               strkeepout_scrlti=se

      

     ut_scrStiocknt(r2_se

      

     ue_sistoocknt(r3_se

 1:
            oo_bch:"",
            '''''+tch['ut_scrStiio_id   store.biniut_scrSti)=             "
    N=se

      

         +tch['raw_ut_scrStiio_id   store.bi_rchxiut_scrSti)=             "
 +tch['ue_sistooud,    aone ue_sisto[1] is None else iue_sisto)=             xin_ray.appg xue_id       )NN tx_i= []_D      )x: tx[Oe_i    oo_bch    N (ue_out']NN tx_))

        rk, satosheut_scriptPubrow in store.selectall("""
            SEL']t.txout_vah']t.txout_scriptPubid)
              F']t.tx
                WHEtxockyed = ?
         ORDER BY Nt.txotx_= ?" g xock'])= 
1:
            oo_bch:"",
            '], txock =             "
     'ut_va': se iu, satos),=             "
     'ut_scriptPub':    store.biniut_scriptPub)}'])
            N= 1:
             c".jg= 10 ** vecaecis 1:
             u, satosg= se iu, satos) 1:
             se egerye u, satosg/ c".j 1:
             fe nye u, satosg% c".j"",
            '], txock =             "
     'ut_va': ("%%d.%%0%dd"g% (vecaecis'])g% (se eger, fe n),=             "
     'raw_ut_scriptPub':    store.bi_rchxiut_scriptPub)}'])
        )NN tx_ray.appg xue_])))



      if (oo_bch:"",
          xn(binouz'sae    a xin_)"",
          xn(bue_ouz'sae    a N tx_)
ns.         retu xe))

    d_ex importodet_cl(   sN_ ], tx_hord, chnlse:
     irylse:
         dbck_h_id  (store.hasrchx(], tx_hd()

     except TyptEueEr:s1:
            raiMalffrmedHx_hackh):
        row = store.selectrow("""
            SEL'], idh'],oss_versh'],o, bl['nTi'], sizo"""
              F']tid)
  )
         WHEutock_h_id = ?
     = ?" gdbck_hd])s           if soonot N=se

      

    return Noh):
     ], idae se int(r0nseD        xfig =            ttx_ho:Eutock_h']),
         (ss_vers':lse int(row[']),
         (, bl['nTi:lse int(r2w[']),
         (sizTi:lse int(r3w_TS            }d)s]
         e, s.uutocclte ys( 

      

    retu =             "
 n ['cha:] = store.gck_chmitainint(r0ns,=             "
 nchain_long':lse int(row['=             "
 n b.block_nTi:lse int(r2w['])            "
 n b.blo  'heigh    aone if r3w[1] is None else inf r3w['])            "
 n b.blotx_ho: d, store.hue_rchx(nt(r4w['])            "
 n], tx_i:lse int(r5nseD               }d)s]
      xn'LE chain_candids']ids   (e, s.uutocc, in store.selectall("""
            SEL'cc.   chain_ cc.chain_long,=             "
    b. b.block_nTi b. b.blo  'heii b. b.block_h']),
              
    blobx.], tx_"""
              F'LE chain_candid cc
                 JOIN blob ob OC ob.blocks']ic ob.block_id)
  )
          J    blobx ob O   blobx ob.blocks']b ob.block_id)
  )
         WHER  blobx.],ock_id """
          ORDER BY cc.   chain_ cc.chain_long DESCi b. b.block_h
        = ?" g xock'])])))



      d, chsoonot N= 1:
               l xn'LE chain_candids'], 1) > 0:
   
         d, chs'] xn'LE chain_candids']rowin ['cha]lse
            else:
             d, chs'] = store.g   aN mid, chack)s]
         e, s.unt(lte ys( 

      

 tx_heut_scr, ut_vah'oock_hh'ootx_ o te [:5]lse
         ut_scr_id   store.biniut_scre'])
  )
    eut_scriptPubrid   store.binint(r5ns       lte , 15    eeut_scr
( 

      

   xock =             "
 "tx_a: se itx_),=             "
 "re.ut_scra: ut_scr,=             "
 "ut_vaa:  = N    ck_vahis is None else ick_va),=             "
 "oock_ha: d, store.hue_rchx(oock_h),=             "
 "ootx_a:  = N    ootx_his is None else iootx_),=             "
 =             in storan orxout_scriptPubo  x, d, chkeut_scriptPuby)")
# MULTICHAIN STy')
           x['ON mud, chout_scriptPub']idsut_scriptPub       lte , 1 5one e] = Nn))
# MULTICHAIN E 

      

    ret    E):

        # XUnneede  ue_ery"".j.
           tue']ids   (e, s.ute , in store.selectall("""
            SEL=             "
 N (tx],inotx_ll(k+ ( ?)""",
            '],in.],inout_scrSti ?)       strkeepout_scrlti    e  ?)""",
            'NULL" ?)k+  ?)""",
            OIN txa+t.txout_va'se

      

     COALESCE(   p  a+, tx_h,  out.txo], tx_hd'se

      

     COALESCE(ut.tx.]t.txotx_h  .]t.txotx_)""",
            OIN txa]t.txout_scriptPubid)
              F']tin
            d)
  LEFT JOIN txoin (   txa]t.txotx_iOIN txut.txock_id)
  )
     d)
  LEFT JOINr   pINxin ONN txoin.tx_id   p  a+, ck_id)d)
  )
     
  LEFT JOt('unlink xino xin Ouxin.txtx_iOIN txin.tock_idd)
  )
        WHEN (txinock_id id)
  )
      ORDER BY N (tx],inotx_
        = ?" g xock'])])))



      # XOncalose ue_ery"".j neede .
           tue_']ids   (e, s.ute , in store.selectall("""
            SEL=             "
 N .tx.]t.txotx_""",
            OIN txa]t.txout_scriptPub""",
            OIN txa+t.txout_va'se

      

     d, n  a+, tx_h,=             "
 N (tx],inotx_id)
              F']t.tx
             )
  LEFT JOIN tout ON (txin.txout_iOIN txout.txock_id)
  )
      )
  LEFT JOIN d, nINxin ON (txin.tx_i d, n  a+,ock_idd)
  )
        WHEut.txxinock_id id)
  )
      ORDER BY N  txout.txotx_
        = ?" g xock'])])))



      drumout_vaslte rys( 

      

    d']0ue

  

        for row te r= 1:
                te  tx['vaiosoonot N= 1:
 e

      

        retu = N 0:
        E       h'] te  tx['vaioE 

      

    ret    E):

     in  b['valinoud, rumout_vasl   tue'])se:
     in  b['value_oud, rumout_vasl   tue_ou)
ns.         retu xe))

    dan ortoin_addretos  sy(   sN_ in_addrord, chain=o,'Olx_te r=-1h'he ts=frozensx.g['dirsel'd 'escte ou])6'])
 D.
 ss_versh're.in_aav    u.decodeee,ebl_in_addrgON muck_ch(in_addr)s           re.in_aaoonot N= 1:
 e

        raiMalffrmedAn_addr("Inut_ck_in_addr"_oie:
 se
 balanNo =g = {}
     rseeived =g = {}
     senm =g =  )
     ed_co_i= [0o]0oE 

     ck_ch_i= [])))



      _injebalanNo tn ose )= 1:
         d, chs']tn ose in ['cha]l 1:
               ch.txsh' not balanNolse:
             d, cn_ray.appgck_ch)se

         ]

 balanNo[   ch.txsaed0ID.
             rseeived[   ch.txsaed0ID.
       
     senm[   ch.txsaed0l 1:
           ]tn ose inhe tout=ed'dirsel'lse:
             ck_vas']tn ose  tx['vaiose

         ]

 balanNo[   ch.txsa'] b['van      ]

         ]tn ose inislue_oulse:
                 senm[   ch.txsa-] b['va=             "
    N=se

      

         rseeived[   ch.txsa'] b['van      ]

       ed_co_[tn ose inislue_oueh'] 1'oe:
 se
 dbck_h_i    store.bisre.in_a)se

     tn ose _i= [])))

         e, s.unt(lislue_, nt(_he to]ck_nTi    chain_   'heii bllock_h' ], tx_hortx_h ut_vah'ut_scrain=Ny= 1:
         d, chs'] = store.gck_chmitainin (chain_ 1:
         tn ose ock =             "
 nhe t':     nt(_he to=             "
 nislue_':   se lislue_)""",
            s b['nTi:    se lb['nT)""",
          "
 n ['cha:]   d, ch""",
          "
 n  'he_':   se l  'he_['])            "
 n blotx_ho: d, store.hue_rchx( blotx_h['])            "
 n],otx_ho:  d, store.hue_rchx(], tx_hd']),
             'tx_i:      se itx_),=         "
     'ut_va':    se iut_va),=             "
 =             if'ut_scrg'] is not N,']

                storan orxout_scriptPubotn ose , d, chkeu  store.biniut_scr)])))

      

    ret tn ose )))

         e, s.udirsellinlte ys
    ret e, s.unt(lTrvah''dirsel'd *te y))

         e, s.udirsellbinlte ys    ret e, s.unt(l = Fah''dirsel'd *te y))

         e, s.uescte linlte ys
    ret e, s.unt(lTrvah''escte 'd *te y))

         e, s.uescte lbinlte ys    ret e, s.unt(l = Fah''escte 'd *te y)))

         re.grseeived(escte ys( 

      

    rew in store.selectall("""
                SEL=              "
    b. b.block_nTi=              "
    cc.   chaini=              "
    b. b.blo  'heii=              "
    b. b.block_h']),
              
    a+, tx_h,=                 "
 N (tx],inotx_,=                 "
 -   p txout.txout_vall(k+ ( ?)""",
                '   p txout.txout_scriptPub ?)    escte     e  ?)k+ ll("",
 ""
              F'LE chain_candid cc
                     JOIN blob ob OC ob.blocks']ic ob.block_id)
  )
              J    blobx ob O   blobx ob.blocks']b ob.block_id)
  )
              J bx ob Obx.],ock_iER  blobx.],ock_id)
  )
              J N (txin ON (txin.tx_id  a+tock_id)
  )
              JOIN tx    p txout ON (txin.txout_id   p txout.txock_ll(k+ ( ?)id)
  )
              JOON multi_e, put mpout Omp.ON multiout_id   p txoe, pubain) ?)    escte     e  ?)k+ ll("",
 ""
              JOe, pubout Oe, puboe, pubain_idll(k+ ( mp)    escte     e     p tx?)k+ ll(oe, pubain_id)
  )
             WHEe, puboe, pubock_h_id = ?
                   'cc.chain_long ] 1ll(k+ ( )    Olx_te r < 0    e ll("",
 ""
          LIMIT Sll(n']),
 ),
                   gdbck_hd]]),
 ),
                      Olx_te r < 0    e]),
 ),
                   gdbck_hd Olx_te rk+ 1)y)))

         re.gsenm(escte ys( 

      

    rew in store.selectall("""
                SEL=              "
    b. b.block_nTi=              "
    cc.   chaini=              "
    b. b.blo  'heii=              "
    b. b.block_h']),
              
    a+, tx_h,=                 "
 N .tx.]t.txotx_""",
            O "
 N  txout.txout_vall(k+ ( ?)""",
                'tx txout.txout_scriptPub ?)    escte     e  ?)k+ ll("",
 ""
              F'LE chain_candid cc
                     JOIN blob ob OC ob.blocks']ic ob.block_id)
  )
              J    blobx ob O   blobx ob.blocks']b ob.block_id)
  )
              J bx ob Obx.],ock_iER  blobx.],ock_id)
  )
              J N .txxin ONN txoin.tx_id  a+tock_ll(k+ ( ?)id)
  )
              JOON multi_e, put mpout Omp.ON multiout_idtx txoe, pubain) ?)    escte     e  ?)k+ ll("",
 ""
              JOe, pubout Oe, puboe, pubain_idll(k+ ( mp)    escte     e  tx tx?)k+ ll(oe, pubain_id)
  )
             WHEe, puboe, pubock_h_id = ?
                   'cc.chain_long ] 1ll(k+ ( )    Olx_te r < 0    e ll("",
 ""
          LIMIT Sll(n']),
 ),
                   gdbck_hd Olx_te rk+ 1]]),
 ),
                      Olx_te r >= 0    e]),
 ),
                   gdbck_hd)])))



     ''dirsel' se'he tr= 1:
         se_te r = re.grseeived( = Faa 1:
               lse_te r, 1 Olx_te r >= 0=se

      

        retu = N     # XC Shous  ulXsX w_in_addrmbasicrve d. 1:
         tn ose rk+ds   (e, s.udirsellin, se_te r])))

      

  tx_te r = re.gsenm( = Faa 1:
               l tx_te r, 1 Olx_te r >= 0=se

      

        retu = N 1:
         tn ose rk+ds   (e, s.udirsellue_,  tx_te r])))



     ''escte ' se'he tr= 1:
         se_te r = re.grseeived(Trvaa 1:
               lse_te r, 1 Olx_te r >= 0=se

      

        retu = N 1:
         tn ose rk+ds   (e, s.uescte lin, se_te r])))

      

  tx_te r = re.gsenm(Trvaa 1:
               l tx_te r, 1 Olx_te r >= 0=se

      

        retu = N 1:
         tn ose rk+ds   (e, s.uescte lue_,  tx_te r])))

         cmp_tn ose (p1ort2ys( 

      

    rew cmp(p1[ b['nTi]ort2[ b['nTi]) \oe:
 se
 







or cmp(p1inislue_ouort2[nislue_i]) \oe:
 se
 







or cmp(p1in  'he_ouort2[n  'he_i]) \oe:
 se
 







or cmp(p1in ['cha].nanTirt2in ['cha].nanT])))
      tn ose r.sorx(cmp_tn ose ))))

        fin ose  se'hn ose rs( 

      

_injebalanNo tn ose ))))

     tos fig =            tre.in_a':  re.in_a']),
         (ss_vers':  ss_vers_=             b['ch_i:   b['ch__=             hn ose ri: hn ose __=             balanNo':  ralanNo_=             senm':     senm_=             rseeived': rseeived_=             ed_co_i:   bd_co_S            }d)s 
       SX w_P2SH_in_addways p= Ne __    kiswn.))



      # XWe wdsoma m sttin_w,awd c Shoutx_oure_sirid_ltinatuads.))

        f(subre.in_a')row in store.selectall("""
            SEL'suboe, pubock_hid)
              F'ON multi_e, put mp
""
              JOe, pubotopout Omp.ON multiout_idtopoe, pubain_id)
              JOe, pubosubout Ompoe, pubain_idsuboe, pubock_idd)
  )
        WHdtopoe, pubock_h_id = ?" gdbck_hd])= 1:
            'subre.in_aash' not tos = 1:
     )

     tos ['subre.in_aa]i= []_D           tos ['subre.in_aa]ray.appgu  store.binisubre.in_a))
ns.         ret tos 
ns     Cectaield x_oicatscks tist rgivenOIN block_ist r_srrensochgicns     numberght aeolicy    fst rgivenOd, cn_r  lt upes LTICNUC   I"UPDns    ght aLTICN.LTICNULAST_BLOCK_ID k_iay.roprsupe.))

    d # eroR  blobogck_chs_ck(storbi    chainrys(          ttopio_id   stoadopllurphahs_bi 0i    chainri    chainry))

        f   chain x_    chainr:se

            sto_ # eroR  blobogck_ch(bi    chainse))

    d_ # eroR  blobogck_ch(ck(storbi    chainnls




     '  t   chain_wiosoonot N= 1:
 e

     chain_long ] 0'):
        N= 1:
           Drawd .rodune a d, chsin_lo fshahist r_urrent d, ch? 1:
           Queryns,est  fst  d,wOIN blo(  fi rklectong descappae ) 1:
           bea rkst r_urrent d, ch_last_ob.blockr  Also e,ebl 1:
          ns,est  fst r_urrent besrg'] ourdtop,ns,uck x_oicatss 1:
          nse waob.bllssrow in_long;nse wacat tay.aplse ve datat 1:
          nrepair scaparios. 1:
        otopo=   ttopio[   chain]row']

 ):
        row = store.selectrow("""
                SEL'b ob.blocki b. b.blo  'heii b. b.blo   chain_w"",
 ""
              F' b.blrbi    c_  id)
  )
             WHEc.   chain_id = ?
                   'C ob.blocks']i.d, ch_last_ob.block= ?" gd, chock'])se

            if = 1:
     )

     inserock' insero  'heii inserain_wd,) = row
   
            inserock !idtop['ob.blockiosht  \oe:
 se

















   store.bi_rse (inserain_w, 1idtop t   chain_wio= 1:
     ]

 ):
        ronot Nse

            if = 1:
     )

     # New in_long    ch. 1:
     )

     chain_long ] 1 1:
     )

     bogconnseli= []_D:
     )

     bogdisconnseli= []_D:
     )

     winnsrock idtop['ob.blockio_D:
     )

     winnsro  'hei idtop['  'heiio_D:
     )

    ns,ule insero  'hei > winnsro  'hei= 1:
     )

         bogdisconnsel.e.uert(0i inserack_idd)
  )
    )

     inserocks'] = store.g   prob.block(inserack_idd)
  )
    )

     insero  'hei -] 1_D:
     )

    ns,ule winnsro  'hei > inssro  'hei= 1:
     )

         bogconnsel.e.uert(0i winnerack_idd)
  )
    )

     winnerocks'] = store.g   prob.block(winnerack_idd)
  )
    )

     winnero  'hei -] 1_D:
     )

     insero  'hei onot Nse

     )

    ns,ule inserock !i winnerock= 1:
     )

         bogdisconnsel.e.uert(0i inserack_idd)
  )
    )

     inserocks'] = store.g   prob.block(inserack_idd)
  )
    )

     bogconnsel.e.uert(0i winnerack_idd)
  )
    )

     winnerocks'] = store.g   prob.block(winnerack_idd)
  )
    )

     winnero  'hei -] 1_D:
     )

        fob.block ch bogdisconnselone:













v

    stodisconnselrob.bl(ob.blocki    chainn_D:
     )

        fob.block ch bogconnselone:













v

    stoconnselrob.bl(ob.blocki    chainn_lse
              b(tx['hP  pio_i'] = store.gck_chmitainin (chain_orenesisock_hg   p: 1:
     )

     chain_long ] 1  # Assuma oncalose renes waob.bllper    ch.   # lse
            else:
             chain_long ] 0']           store.sql("""
            INSERT I'LE chain_candid (se:
                chain_ ob.blocki chain_long_ ob.blo  'heise:
         )    VALUES, S (?, ?, ?)""",
               (   chain_ o['ob.blockioi chain_long_ o['  'heiio)])))



      chain_long 1) >se

            store.sql("""
             l("UPDO   ch"""
 ""
                d, ch_last_ob.blain_id = ?
  )
             WHE   chain_id = ?" gtop['ob.blockioi    chain)])))



         stonse.txrstbi rkn_c o['  'heiouain is not None:









(pt_addr_v,)row = store.selectrow("""
                SEL'   chain_address_vers
    ds
              F'LE ch= ?
  )
             WHE   chain_id = ?" gd, chock'])se






v

    stodoess_v.txrstbi r(pt_addr_v_ o['ob.blockio])))

    d # eroexispend_ob.bl(ck(storck_hi    chainnls




   ob.blo   row = store.selectrow("""
            SEL'ob.blocki  b.blo  'heii  b.blo   chain_w']),
 ),
             b.block_nTi R  blobolecgseconds']),
 ),
             b blobolecgk, satoshe b blgk, satogseconds']),
 ),
             b blobolecgks
""
              F' b.blid)
  )
         WHER  block_h_id = ?
     = ?"    (store.has(tx_hd'))'])

       iis  ob.blo   s( 

      

    rew  = Fa'])

       i   chainsoonot N=se

      

    retuTrvad)s 
       BN bloceaderghlreadyiseet.  Drs'rdre.impfst rob.bl,)s 
      idutliryeld in_fi eldfst r   ch. s




   ofig =            "ob.block=:   ob.blo   row,=            "  'hei=:     ob.blo   r1w,=            "   chain_w=:    store.bi_rse (ob.blo   r2w['])           "ck_nT=:      ob.blo   r3w,=            "seconds=:    ob.blo   r4w,=            "s, satos=:   ob.blo   r5w,=            "ss=:         ob.blo   r6w,=            "bolecgks=:   ob.blo   r7]}'])

       w = store.selectrow("""
            SEL'1"""
              F'LE chain_candidid)
  )
         WHER  blain_id =                  E   chain_id = ?"ne:













v

      b['ob.blockioi    chain)]>se

            stolog.e.fo("ob.bl %dghlready x_    ch %d)""",
                   

v

b['ob.blockioi    chain)'):
        N= 1:
            o['  'heioua== 0=se

      

     b(tx['hP  pios'] = store.gck_chmitainin (chain_orenesisock_hg   plse
            else:
             b(tx['hP  pios']'dummy'   iFo"l adopllurphahs.se

            sto # eroR  blobogck_chs_bi frozensx.g[n (chaino)])))





    retuTrva)))

    dtx_fid, noR  bls_ck(storbb.block_:))





    i= []))

        for row in store.selecta 1:
         "   SELEd, noR  block    F' b.blid, n    WHER  blain_id )""",
         (ob.blocki)ys( 

      

    ray.appint(r0nseD    

    ret    )))

    dtx_fgck_chsgcont_chend_ob.bl_ck(storbb.block_:))





    i= []))

        for row in store.selecta 1:
         "   SELEn (chain    F'LE chain_candid    WHER  blain_id )""",
         (ob.blocki)ys( 

      

    ray.appint(r0nseD    

    ret frozensx.g   ])))

    dre.g   prob.block(ck(storbb.block_:)D    

    retw = store.selectr 1:
         "   SELE   prob.block    F' b.bl    WHER  blain_id )""",
         (ob.blocki)yr0n)))

    ddisconnselrob.bl_ck(storbb.blocki    chain):]           store.sql("""
         l("UPDO   chain_candidid"
                chain_long ] 0id)
  )
         WHER  blain_id     E   chain_id = ?"ne:













v
(ob.blocki    chainn])))

    dconnselrob.bl_ck(storbb.blocki    chain):]           store.sql("""
         l("UPDO   chain_candidid"
                chain_long ] 1id)
  )
         WHER  blain_id     E   chain_id = ?"ne:













v
(ob.blocki    chainn])))

    dinokup_]t.tx(ck(storutock_hh']t.txotx_ash):
        row = store.selectrow("""
            SELEIN txout.txock, N  txout.txout_vaid)
              F']t.tx, N idd)
  )
        WHEut.txxinock_id  a+tock=                  E  a+, tx_h_id =                   N .tx.]t.txotx__id = ?"ne:



",
 ",
        (store.has(], tx_hd'']t.txotx_aseD    

    ret (in=o,'in=Ny    if soonot N    e (   row,lse int(row[),)")
# MULTICHAIN STy')
    dinokup_]t txout_scne, pub(ck(storutock_hh']t.txotx_ash):
        row = store.selectrow("""
            SELEIN txout_scriptPubid)
              F']t.tx, N idd)
  )
        WHEut.txxinock_id  a+tock=                  E  a+, tx_h_id =                   N .tx.]t.txotx__id = ?"ne:



",
 ",
        (store.has(], tx_hd'']t.txotx_aseD    

    ret ot N    if soonot N    e    rown))
# MULTICHAIN )))

    dut_scr_ho_e, putock(ck(sto d, chkeut_scrys():         Exte nsoin_addwaht aut_scr'he t fromote transact .txputaut_scr.ow("""
     ut_scr_he torve dav == chae, s.u   txout_scr(ut_scry'])

       w t_scr_he else ( = ChaAX_SCREMA_TUADDRESS,n = ChaAX_SCREMA_TUP2SHys( 

      

    rew in stoe, pubkey_h_ho_ew_ve d),)")
# MULTICHAIN STy')
       w t_scr_he ea==n = ChaAX_SCREMA_TU
# MULTICNUP2SHs( 

      

    rew in stoe, pubkey_h_ho_ew_ve d, LL_PUB_FLAGSUP2SHy
y')
       w t_scr_he ea==n = ChaAX_SCREMA_TU
# MULTICNs( 

      

    rew in stoe, pubkey_h_ho_ew_ve dy
y')
       w t_scr_he ea==n = ChaAX_SCREMA_TU
# MULTICNUENTITY_PERMISVERNs( 

      

    rew in stoe, pubkey_h_ho_ew_ve d['e, pubkey_ha]d,))
# MULTICHAIN 
y')
       w t_scr_he ea==n = ChaAX_SCREMA_TULL_PUBs( 

      

    rew in stoe, pubkho_ew_d, chkeve dy
y')
       w t_scr_he ea==n = ChaAX_SCREMA_TU
# MUSIGs( 

      

w t_scrkey_hav == cha t_scrkey_hiut_scre'])
  )
    eON multiout_i in sto_e, putock(ct_scrkey_h, ut_scry'])

           iis w = store.selectro   SEL'1    F'ON multi_e, put    WH'ON multi_in_id )" (ON multiocki)ys( 

      

        fe, putrow iet_ve d['e, pubs']ys( 

      )
         e, pub.tk_idnt(stoe, pubkho_ew_d, chk e, pub)ne:













v

    store.sql("""
                        INSERT I'ON multi_e, put (ON multiocki e, pubain_id)
  )
                    VALUES, ?, ?)" (ON multiocki e, pubain_)( 

      

    rew ON multiock
y')
       w t_scr_he ea==n = ChaAX_SCREMA_TUBURN:oe:
 s    

    rew LL_PUB_ID_NETWORK_FEE
eD    

    ret ot N)))

    de, pubkey_h_ho_ew_   store, pubkey_h, flags=0_:)D    

    ret in sto_e, putock(e, pubkey_h, ot N, flags))))

    de, pubkho_ew_   stord, chk e, pub, flags=0_:)D    

 e, pubkey_hav == chae, pubkey_h(e, pub))D    

    ret in sto_e, putock(e, pubkey_h, e, pub, flags))))

    d_e, putock_   store, pubkey_h, e, pub, flags=0_:oe:
 se
 dbck_h_i    store.bise, pubkey_h)   ire.bi,iis wre.has    f160-bi h):
        row = store.selectrow("""
            SELEe, putockid)
              FEe, putidd)
  )
        WHEe, pubock_h_id = ?" gdbck_hd])y')
       w   s( 

      

    rew nt(row
1:
    Ee, putock_idnt(store.new_ie, put"y
y')
       Ee, putain is not Naht aleise, pub, 1 MAXULL_PUBs( 

        Ee, put onot N']           store.sql("""
            INSERT I'e, put (e, putockore, pubkey_h, e, pub,re, pubkflags)"""
            VALUES, S (?, ?, ?)""",
               (e, putockordbck_hd    store.bise, pub), flags aseD    

    ret e, putocki))

    dtlu_h(   st):])

       w = stoittes_ltnNoays cip 1) >se

            stoys cipacse

            stolog.debug("ys cip"cse

        w = stoittes_ltnNoays cip ] 0i))

    dre.impedmittes_   storsizt):]       w = stoittes_ltnNoays cip +=rsizt])

       w = stoittes_ltnNoays cip 1=    stoys cipmittes>se

            stotlu_h(])))

    dcatch_up(   st):])

        fdircfgrow in stove ddirs>se

         iryls  )
    )

     inaderg=fdircfg['inaderios  fin sto   aN miinaderrow
   
            inaderg== "obkfule"one:













v

    stocatch_upudir(dircfi)=             "
      inadergse ("rpc?" "rpc,obkfule"" "   aN m"ys( 

      )
           iis w = stocatch_upurpc(dircfi)s( 

     ow
   
            inaderg== "rpc?s( 

     ow
   
 1:
 e

        raiExcepsact("RPC inad
fluled"cse

        we

            stolog.debug("catch_upurpc: abimp"cse

        we

            stocatch_upudir(dircfi)=             "
    elsow
   
 1:
 e

        raiExcepsact("Unkiswn ve ddir inader: %s"g% inader])))

 e

            stotlu_h(])))

 )

     exceptiExcepsact, els   we

            stolog.excepsact("Faitaield catchdnt %s"" dircfi)=     

            storolhbllb(])))

    dcatch_upurpc_   stordircfi)s( 

     ql("""
     Lnad d,wOIN bln usendlRPC.  Re_siris runnendl*c".t auup.impend"""
     re.IN blck_hd re.IN bl,aht are.rawte transact.  Bitc".t av0.8"""
    Bre_siris to  N (tdexdconfigurasact upsact.  Re_siris    chain])

      n to  ve ddir  dale.( 

     ql(")")
# MULTICHAIN STy')
     #iExpht a~  n ON muck_ch   ldereld userehoma dirse  stidd)
  )
dircfg['dirnanTioa=losae,th.expht user(dircfg['dirnanTio)y')
     #iExte nsock_ch nant fromolast e,thays p= Ne d # ON muck_ch   ldery')
    '   chananas=losae,th.atatnana(dircfg['dirnanTi]d,))
# MULTICHAIN 
y')
    E   chain_iddircfg['   chain']])

       i   chainsoonot N=se

      

    stolog.eueEr("noi   chaid"c( 

      

    rew  = Fa'        d, chs'] = stod, chsmit.tx[n (chaino
y')
    Econffule_iddircfgore.('conf')   f   chove ddir_conf_fuleananay')
    Econffule_=losae,th."".j(dircfg['dirnanTi],Econffule)se:
     irylse:
         confyeddinx(['une.st_sc().s du.g"=", 1]]),
 ),
   w
   
            "="  n 'une]),
 ),
   w
   
            e ('une.st_sc(), Trvaa 1:
        
      

         'une  n upeisconffule)s),
 ),
   w
   
            'une !idllaht  'unerowsh' not "#\r\n"]d,)

     exceptiExcepsact, els   we

        stolog.eueEr("faitaield inad %s: %s",Econffule, e)( 

      

    rew  = Fa'])

     rpcusereaaaa=Econfore.("rpcuser",El(n])

     rpcpassin_da=Econf["rpcpassin_d"]])

     rpcconnselaa=Econfore.("rpcconnsel",El127.0.0.1(n])

     rpc.impeaaaa=Econfore.("rpc.imp",E   chove ddir_rpc.impn])

     urla=E"http://(k+ rpcuserk+ ":(k+ rpcpassin_da+ "@(k+ rpcconnsela\oe:
 se





+ ":(k+ st_(rpc.impn")")
# MULTICHAIN STy')
 )

    drpc(funcd *e, ams]>se

            storpclog.e.fo("RPC>> %s %s %s"o'   chananTi'funcd e, ams)( 

      

    av    u.jsonrpc(   chananTi'urli'funcd *e, amsd,))
# MULTICHAIN 
y')
            (   storpclog.esEndaledFEr(loggend.INFO)ys( 

 e

            storpclog.e.fo("RPC<< %s"o'e:
                             
   .sub(r'\[[^\]]{100,}\]'d '[...]'d st_(   ])]E 

      

    ret    E):

        dre.gIN blck_hl  'he_[>se

         iryls  )
    )

        ret  pc("re.IN blck_h"o'  'he_[))

 )

     excepti   u.JsonrpcExcepsact, els   we

            toysdelse (-1h'-5h'-8h'-711ys( 

 e

       
       BN bl numbergou d # ra_lo...( 

 e

       
        -1soonlegacy ysde""  (-10.0), renericreueEr( 

 e

       
        -8 (RPC_IN   ID_PARAMETER) txrstiseetnot bitc".t a10.x( 

 e

       
        -5 (RPC_NOT_FOUNDys Beetnsuglongek ch #bitc".t-dev as m stiay.roprsupe( 

 e

       
      -711 (RPC_BLOCK_NOT_FOUNDys MN mu = ChOIN bl if (eou.freueEr 1:
 e

      

        retu = N 0:
        E       ra
ns.        R  rets -1sonreueErd srawd'll il.N0sonrempty'LE ch= ?
  )
'  'he_s'] = store.g b.blidumber(   ch.tx)k+ 1E):

        dre.gtx(rpco], tx_h[>se

         iryls  )
    )

      pco], texd=  pc("re.rawte transact"o'rpco], tx_h[
))

 )

     excepti   u.JsonrpcExcepsact, els   we

            toysdel!id-5 ht  toysde!id-710:   d-5 ord-710: te transactsh' not (tdex.sow
   
 1:
 e

        ras   we

           '  'he_s!id0= 1:
 e

      

        retu = N  1:
 e

           The renes wate transacts waunavaitdale.  Thiss w 1:
 e

          sh'reci.'e:
            dre.imp renes wo],s  )
    )

      pco], texd= renes wo],ore.(rpco], tx_h[s   we

           ' pco], texsoonot N=se

        we

        stolog.eueEr("renes wate transactaunavaitdale vialRPC;"'e:
                             
   qiseedre.imp-txson abtoconf") 1:
 e

      

        retu = N  1:
 e

      pco],d=  pco], tex.decodei'chx') 1:
 e

     ], tx_hd=  pco], tx_h.decodei'chx')[::-1n  1:
 e

    ays pupedm xkey_hav == chate transactkey_h( pco],) 1:
 e

        in tx_hs!iays pupedm xkey_h= 1:
     )

     #   raiInut_ckBN bl('te transactatx_hsmismatch')    we

            stolog.debug('te transactatx_hsmismatch: %rs!i %r'orutock_hhays pupedm xkey_h)
 0:
        Einav == chae, s.u e transact( pcortn 0:
        End(tx['hasav ], tx_h 0:
        d   retu xe):

        dtxrst_d,wrob.bl_  'heiiEd, n tx_h[>se

  

     ql(Fit  seedtxrst d,wOIN bl.   ']    )

    ns,ule   'hei 1) > 0:
   
         ey_havdre.gIN blck_hl  'he_ - 1]]s   we

           ' k_hain is not Naht a(1,)roow = store.selectrow("""
                    SEL'1"""
 ",
 ""
              F'LE chain_candid cc
                         JOIN blob ob Occ ob.blocks']b ob.block_id)
  )
                 WHER.R  block_h_id = ?
  ?
                   'C ob.blo  'he_ IS NOT'NULL= ?
  ?
                   'cc    chain_id = ?" g= ?
  ?
                d  (store.hasrchx(st_(tx_h[)h'   ch.tx)ys( 

 e

       
     break]s   we

        Ed, n tx_h_idtx_hs   we

        E  'hei -] 1_ 0:
        d   retu_  'heiiEd, n tx_h[_ 0:
        dcatch_upumempo"ll  'he_[>se

         #dre.impedu xdcae,ed srawddcan avoin_queryendlDBsonreae, passlse
         re.impedo],d= ieta)ne:
           N, nE  'hei e,ebl b'nT
e

        E  'heigckwd, b'nT.b'nT()k+ 1E):

 )

    ns,ule    storpciinadumempo"l= 1:
     )

     # Ie.impfst rmem st po"l.( 

      

          pco], tx_hson  pc("re.rawmempo"l"ys( 

      )
           i pco], tx_hson re.impedo],:Econpenvad)s 
   
       
       Breakdinop    d,wOIN bl(eou.f( 

      )
           E  'heigckwd< b'nT.b'nT(ys( 

      ))
    )

      pcoey_havdre.gIN blck_hl  'he_)ne:
          )
           i pcoey_h= 1:
     )

   )
    )

        ret  pc tx_h 0:
        de

        E  'heigckwd, b'nT.b'nT()k+ 1E):

 )

    n       Einav re.gtx(rpco], tx_h[( 

      )
           Etxsoonot N=se

        we:
           NB:XOn d,wOIN bln,  lderemempo"lEtxsared #tensmissendse

        we:
           This tay.apsdsoma ost  fs'nTseldo, just il.Nodr_one wse

        we

            stolog.e.fo("txs%s gt N fromemempo"l"g% rpco], tx_h[( 

      )
            Econpenvad)s 
   
       
        # XRaceEco_casacts n 'f sooolasact lev   .( 

     e:
         inock_idnt(store.tx_find_id_and_va_
#,  = Fah'e,ebl_onca=Trvaa 1:
        
           ]t txsoonot N=se

        we:
         inock_idnt(store.import_
#,  = atord, ch)se

        we

            stolog.e.fo("mempo"lEtx %d)" inock)se

        we:
        dnt(store.impedmittes(+= 'sizo'nsewe:
        d       re.impedo],.in_(rpco], tx_h[(
   we

            stolog.e.fo("mempo"lEinadays pleped,   ampendNodr_...") 1:
 e

      

 b'nT.sleep(3)se

      

    return Noh):
     ]rylsne:
           Ge  ob.bl' k_haanE  'hei,aht a tist rsanT b'nT" iongne:
           bitc".t aconnselivity.se

         iryls  )
    )

     d, noey_havdre.gIN blck_hl  'he_)ne:
         excepti   u.JsonrpcExcepsact, els   we

            ra))

 )

     exceptiExcepsact, els   we

           Connselivity
flulusto
       we

        stolog.eueEr("RPC
fluled: %s",Eaa 1:
  

      

    rew  = Fa'])

           Ge  seedtxrst d,wOIN bl (inokendNbllbwardaun  u' k_hamatcha 1:
  

       'heiiEd, n tx_h =dtxrst_d,wrob.bl_  'heiiEd, n tx_h['])

 )

     # Ie.imp d,wOIN bl .(    )

      pcoey_havdd, n tx_h ordre.gIN blck_hl  'he_)ne:
           i pcoey_hsoonot N=se

     )

      pcoey_havdcatch_upumempo"ll  'he_[):

 )

    ns,ule  pcoey_ha'] is not N,']

             tx_hd=  pc tx_h.decodei'chx')[::-1n  1:
 e

    a      w = sto # eroexispend_ob.bl(tx_hh'   ch.txys(     ))
    )

      pcoey_havdre.gIN blck_hl  'he_k+ 1)=             "
    elsow
   
 1:
 e

      pcoIN bl =  pc("re.IN bl"o'rpcotx_h[( 

      )
         asuert  pcoey_hav=  pcoIN bl(tx['has
"",
                '   poey_hav \oe:
 se
















  pcoIN bl(t   piousIN blx['has.decodei'chx')[::-1n \oe:
 se




 e

    a      wt   piousIN blx['has n  pcoIN bl \oe:
 se



           "
    e'   ch.renesisock_hg   ploe:
 se



          IN block =             "
         ttx_ho:     tx_h,=            ),
         (ss_vers': lse i pcoIN bl((ss_vers'ns,=            ),
         tx['hP  pi:'   poey_h,=            ),
         tx['hMerkleRool'lse:
 e:
 se
















  pcoIN bl(tmerkleroolas.decodei'chx')[::-1n,=            ),
        s b['nTi:   lse i pcoIN bl((b'nT'ns,=            ),
         tnBitsi:   lse i pcoIN bl((bitsi],f16s,=            ),
         tnot cTi:  lse i pcoIN bl((nt cT'ns,=            ),
         'te transactsi: [n,=            ),
         (sizTi:l   lse i pcoIN bl((sizT'ns,=                     "
 n  'he_':     'heii=              "
        }d)s 
     1:
               ch ob.blo eaderkey_h(   ch sersulizT_ob.blo eaderg= ?
  ?
        


          IN bl))s!i ey_h= 1:
     )

   )
    )

    raiInut_ckBN bl('IN blatx_hsmismatch')  1:
  

      

          pco], tx_hson  pcoIN bl((bx']=se

        we:
         in_idnt(stoex import(], tx_h_idntr(rpco], tx_h[o'e:
                             
     

        mat_id"re.ary") 1:
  

      )
           Etxsoonot N=se

        we:
            Einav re.gtx(rpco], tx_h[( 

      )
                   Etxsoonot N=se

        we:
            E       stolog.eueEr("RPC
serviceElllbs'full N (tdex")se

        we:
            E       rew  = Fa'])

        


          IN bl['te transactsi]ray.appg x)  1:
  

      
     dnt(store.imlrob.bl(ob.blh'   chav == ch) 1:
  

      
     dnt(store.imledmittes(IN bl((sizT'ns(     ))
    )

      pcoey_hav  pcoIN blore.('d, nIN blx['ha)  1:
  

      
    'he_k+] 1id)
 e:
           i pcoey_hsoonot N=se

     )

          pcoey_havdcatch_upumempo"ll  'he_[):

 )

    n)

     # Also inokNbllbwards x_  tatawddappdntsonran urphahOIN bl.
       we:
           NB: Cectsonlyns,en  pcoey_ha'] is not N, ost  w ra
       we:
              awd'llNodr_ridedcatch_upumempo"l's behapior.
         )
           i pcoey_h= 1:
     )

   )
    )

   'heiiE pc tx_h =dtxrst_d,wrob.bl_  'heiiErpcotx_h[(
        excepti   u.JsonrpcMestodNotFou.f, els   we

        stolog.eueEr("bitc".t a%] is auup.imped", e.mestod)( 

      

    rew  = Fa'])

     exceptiInut_ckBN bl, els   we

        stolog.eueEr("RPC ve d is au.fer   od: %s", e)( 

      

    rew  = Fa'])

     r  retuTrva)))

 # Lnad ectOIN bl    ampendNatfst r_urrent fulNaht a # iet.))

    dcatch_upudir(   stordircfi)s( 

         upei_obkfule(dumber]>se

            stogrsfre_hgdircfi(dircfi)=            obkfuleock =             "
 nntream's BCDe dStream.BCDe dStream()""",
            s banT':    storbkfule_nana(dircfg, number)""",
            s bumber': bumber=             "
 = se

         iryls  )
    )

     fuleockupeisrbkfule['nanTi],E"rb")se

         exceptiIOEueEr, els   we

           Earlynbitc".t aused obk0001.datfso obk9999.dat. 1:
     )

     # Nf sotausesOIN bl /obk00000.datfso IN bl /obk99999.dat. 1:
     )

     # Abe   ampsOIy assumendfst rffrme fie,enT.   fawdddrs'r 1:
     )

     # fit  seedex ecped fuleodutddriseedIN bl /obk00000.dat, 1:
     )

     # switchfsofst  d,wfie,enT.  Recor  see switchOIy addend 1:
     )

     # 100000fsoreae, fule bumberd sraffrdexa ple, 100123eme tr 1:
     )

     #dIN bl /obk00123.datodutd123us  ulXme tr obk0123.dat.id)
 e:
           irbkfule['number'] 1)9999 frde.euenos!i eueno.ENOENT:sow
   
 1:
 e

        ras   we

         d,wrnumber = 100000s   we

         rbkfule['nanTi] =    storbkfule_nana(dircfg, d,wrnumber)s  )
    )

     fuleockupeisrbkfule['nanTi],E"rb")se

            irbkfule['number'] = d,wrnumber se

         iryls  )
    )

     rbkfule[nntreami]r   _fule(fule, 0)))

 )

     exceptiExcepsactls   we

           m   dcan
flulsonranrempty'fule,odutdempty'fulessared kay.s  )
    )

     fule.seek(0ilosaSEEK_IN [s   we

           'fule.tecta)a== 0=se

   )
    )

     rbkfule[nntreami]rinpup_idllse

   )
    )

     rbkfule[nntreami]rread__ursfrd= 0=             "
    elsow
   
 1:
 e

     rbkfule[nntreami]r   _fule(fule, 0)))

 )

     fitectyls  )
    )

     fule.cinse()se

            stolog.e.fo("Opeied %s", rbkfule['nanTi])( 

      

    rew rbkfule_ 0:
        diry_cinse_fule(ds[>se

         iryls  )
    )

     ds.cinse_fule()))

 )

     exceptiExcepsact, els   we

            stolog.e.fo("BCDe dStream: cinse_fule: %s", e)(se:
     irylse:
         obkfuleoc upei_obkfula(dircfg['obkfularnumberi])(        exceptiIOEueEr, els   we

        stolog.warnendro kippend ve ddir %s: %s",Edircfg['dirnanTi], e)( 

      

    rew(se:
    ns,uleuTrvals   we

     dircfg['obkfularnumberi] =irbkfule['number']s   we

     ds =irbkfule[nntreami]
    )

     d, norbkfule onot N se

         iryls  )
    )

     nt(store.imlrrbkve (dircfg, ds, rbkfule['nanTi])))

 )

     exceptiExcepsactls   we

            stolog.warnendroExcepsactNat %d) % dsrread__ursfr[s   we

         iry_cinse_fule(ds[ 0:
        E       ra
ne

            d, norbkfulesoonot N=se

     )

     #uTry anost   fule.se

 e

         iryls  )
    )

         d, noobkfuleoc upei_obkfula(dircfg['obkfularnumberi]k+ 1)=    e

         exceptiIOEueEr, els   we

               de.euenos!i eueno.ENOENT:sow
   
 1:
 e

            ras   we

     )

     # Nf m stdIN bl'fules. 1:
 e

      

        ret 1:
 )

 )

     exceptiExcepsact, els   we

               dre.attr(ah''eueno','in=Ny =i eueno.ENOMEM:sow
   
 1:
 e

         # Assuma 32-bisoin_addwaspace exhaussact.se

        we

            stolog.warnendg= ?
  ?
        


          "Cannos ectocat rmem st ffr d, ndIN blfule: "= ?
  ?
        


          "skippend safety'e,ebl")se

        we

         iry_cinse_fule(ds[ 0:
        E            obkfuleoc upei_obkfula(dircfg['obkfularnumberi]k+ 1)=    e

        we

     dircfg['obkfular # ieti] =i0( 

      )
            Econpenvad  
 1:
 e

            ras   we

     )

 fitectyls  )
    e

            d, norbkfulesoonot N=se

     )

             iry_cinse_fule(ds[ se

     )

     # Lnad eny ve d writtenfsofst  last fulesltnNoawd'e,eble .s  )
    )

     nt(store.imlrrbkve (dircfg, ds, rbkfule['nanTi]))s   we

           Conpenvaone wfst  d,w fule.se

 e

         obkfuleoc d, norbkfule

e

         iry_cinse_fule(ds[ 0:
        Edircfg['obkfular # ieti] =i0)))

 # Lnad ectOIN bl  fromest rgivenOve d ntream.))

    dre.imlrrbkve (   stordircfg, ds, fulananT="[unkiswn]"ys( 

     fulanum =idircfg['obkfularnumberi] 0:
      srread__ursfrd=Edircfg['obkfular # ieti](se:
    ns,ule fulanum ==idircfg['obkfularnumberi]= 1:
             srread__ursfrk+ 8 1)lan(dsrinpupys(e

       
     break]s   we

      # ietd=E srread__ursfrs   we

     chgicd=E srreadmittes(4))s   we

     # Assuma nosreal chgicdnumber   ampsOne wfa'NUL. 1:
            chgicrowg== "\0"ls   we

            fulanum 1)99999aht achgicg== "\0\0\0\0"ls   we

       
     # As  # Bitc".t 0.8, fulasd #tenset ane wfa'NULaspat.se

        we

      srread__ursfrd=  # iet( 

 e

       
     break]e

       
     #  kip'NULaittes andIN blset .s       we

      srread__ursfrd=  # iet( 

 e

       
 s,ule  srread__ursfrd<)lan(dsrinpupys(e


















sizTd= men(lan(dsrinpupy -  srread__ursfr, 1000)=    e

        we

Ove dd=E srreadmittes(sizt).lst_sc("\0"a 1:
        
           (ve dd!idllys(e


e

        we

      srread__ursfrd-=)lan(de da 1:
  

 e

       
     break]e

       
        stolog.e.foro kipped %d'NULaittes andIN blset "o'e:
                             srread__ursfrd-  # iet)
 )
            Econpenvad)s 
   
     # AssumaOIN bl  obeyest raddpseliveaeolicy    st y il.Nt  e.se

 ')
    E   chain_iddircfg['   chain']])

         d, chs'] = stod, chsmit.txore.(   chain,'in=Nyl 1:
               chsoonot N=se

 )

         d, chs'] = stod, chsmit.chgicore.(chgic,'in=Nyl 1:
               chsoonot N=se

 )

            stolog.warnendg= ?
  ?
        


  " = ChOif (eou.frffr chgicdnumber %] ChOIN bl'fule %] an"= ?
  ?
        


  "  # iet %d.",Echgicoencodei'chx'), fulananT,  # iet)
= ?
  ?
        
if _chgicg=Echgic]e

       
     # Readnse w fula'] Chasaal chgicdnumber.s       we

     chgicg=Edsrinpup[0:4n  1:
 e

    a      wchgicg==
if _chgic:se

        we

      srread__ursfrd=  # iet( 

 e

       
     break]]e

       
        stolog.e.fog= ?
  ?
        


  "Scannendlffr Chasaal chgicdnumber %]."o'e:
                Echgicoencodei'chx'))
s       we

      srread__ursfrd=  # iet( 

 e

       
  # ietg=Edsrinpup.fit (chgic,  # iet)
1:
 e

    a        # ietg== -1:
       we

            stolog.e.fo("Mhgicdnumber  canau.succddwful.")( 

 e

       
     break]]e

       
        stolog.e.fog= ?
  ?
        


  "Skipped %d'ittes ChOIN bl'fule %] an  # iet %d.",= ?
  ?
        


   # iet -  srread__ursfr, fulananT,  srread__ursfr)
s       we

      srread__ursfrd=  # iet( 

 e

       
 conpenvad)s 
   
     lang wf=E srreadmse 32() 1:
             srread__ursfrk+ lang w 1)lan(dsrinpupys(e

       
        stolog.debug("inys plepeOIN bl  # lang w %d    ch %d)""",
                   

v

     lang hh'   ch.txys       we

      srread__ursfrd=  # iet( 

 e

       
 break]e

       
set a=  srread__ursfrk+ lang wd)s 
   
     ey_hav == chads_ob.blo eaderkey_h(ds[ s      
        # Xsh Shoudecode  amre.aht ae,ebl' k_haag chstfi elds      
       avoinEinadendlgarbag  ve d.  ButOif (eorememred-mened frs  
           CPU-mened d, chscks tius  vi# erent proof-of-in_w"",
 " 
       algore wms.'])

           iis w = sto # eroexispend_ob.bl(tx_hh'   ch.txys(     ))
    )

 bav == chads_e, s._ob.bl(ds[(     ))
    )

 b["ck_h"]_idtx_hs(     ))
           (   stolog.esEndaledFEr(loggend.DEBUG)aht ab["x['hP  p"]_i='   ch.renesisock_hg   pys(    e

 e

         iryls  )
    )

                stolog.debug("C  ch %d renes watx: %s"h'   ch.tx""",
                   

v

         )

 b['te transactsi]row['__ve d__']oencodei'chx')[(     ))
)

 )

     exceptiExcepsactls   we

                 passl
 

      
     dnt(store.imlrob.bl(oh'   chav == ch) 1:
  

      
      srread__ursfrs!i enk=     )

                stolog.debug("Skipped %daittes andIN blset "o'e:
                               
set a-  srread__ursfr)
s   we

      srread__ursfrd= et 
se

        w = stoittes_ltnNoays cip += lang wse

 )

       w = stoittes_ltnNoays cip 1=    stoys cipmittes>se

            w = stosave_obkfular # iet(dircfg, dsrread__ursfr[s   we

            stotlu_h(]s   we

            stogrsfre_hgdircfi(dircfi)=
     
      srread__ursfrs!=Edircfg['obkfular # ieti]:
           w = stosave_obkfular # iet(dircfg, dsrread__ursfr[s))

    drbkfule_nana(   stordircfg,dnumber=ot t):])

       dnumbersoonot N=se

 )

    dnumber =idircfg['obkfularnumberi] 0:
       dnumbers1)9999s( 

      

    rewlosae,th."".j(dircfg['dirnanTi],E"ob.bls"h "obk%05d.dat"'e:
                             % (numbers- 100000d])y     

    rewlosae,th."".j(dircfg['dirnanTi],E"obk%04d.dat" % (numberd])s))

    dsave_obkfular # ie (   stordircfg,  # ie ):]           store.sql("""
         l("UPDOve ddirid"
                obkfularnumber_id o'e:
                obkfular # ie _id idd)
  )
        WDOve ddirain_id = ?"ne:













v
(dircfg['obkfularnumberi],dnt(stornpen( # ie )o'e:
                dircfg['ckio])])

       w = stoectbd_coa)a==) >se

            store.sql("""
                INSERT I've ddir (ve ddirainordirnanT, obkfularnumbero'ee:
                obkfular # ie i    chain)'):                 VALUES, S, S (?, ?, ?)""",
               

v
(dircfg['ckio,Edircfg['dirnanTi],
   e

        we

     dircfg['obkfularnumberi],
   e

        we

    dnt(stornpen( # ie )oddircfg['   chainio])]       Edircfg['obkfular # ieti] =i # iets))

    dgrsfre_hgdircfi(   stordircfgash):
        row = store.selectrow("""
            SELEobkfularnumbero obkfular # ie id)
              FOve ddiridd)
  )
        WDrdirnanT_id = ?" gdircfg['dirnanTi]d])y')
       w   s( 

      

 numbero  # ie _is   (rnp,w   ) 1:
            (numbers1 dircfg['obkfularnumberi] Er 1:
 e

      

 (number ==idircfg['obkfularnumberi]aht  1:
 e

      

   # ie _>Edircfg['obkfular # ieti])ys(       we

     dircfg['obkfularnumberi]_isnumber(       we

     dircfg['obkfular # ieti] =i # iets))

    dre.g b.blidumber( = sti    chainash):
        row = store.selectrow("""
            SELEob.blo  'he_"""
              F'LE chain_candidid)
  )
         WHELE chain_id =                   chain_long ] 1id)
  )
      ORDER BYEob.blo  'he_ DESCid)
  )
      LIMIL'1= ?" gd, chock'])se





    rewlrnpint(r0ns   w       e -1s))

    dre.g amre.( = sti    chainash):
        s = in store.selectall("""
            SEL'C ob.blonBits
""
              F' b.blrbid)
              J    c_   ob OC ob.blocks']i.d, ch_last_ob.block)
 )
             WHEc.   chain_id = ?" gd, chock'])se





    rewl   u.calculdidg amre.(rnpint(sr0nr0nss   w   s    enot Ns))

    dre.grseeived_id__last_ob.block( = sti    chockore, pubkey_ho'e:
                               
s   IN blo  'hei onot Nash):
     re. onll("""
            SEL'COALESCE(nd_va_sum, 0),]i.d, ch_last_ob.block"""
              F'LE ch   LEFT    J (

                SEL' c.   chockorSUM(N  txout.txout_va) nd_va_sumid)
              FEe, putidd)
  )
         J ut.txd)
  )
       ob Out.txoe, pubain_ide, puboe, pubain_id)
              J  b blobx  )
       ob O b blobxxinock_id   txoutain_id)
              J  b bl b            ob OC ob.blocks'] b blobx ob.blain_id)
              J LE chain_candid cc ob Occ ob.blocks']b ob.block_id)
  )
          WH'e:
              de, puboe, pubkey_h_id     'e:
              ' c.   chock_id     'e:
              ' c.chain_long ] 1ll( + g= ?
  ?
           l( if IN blo  'heisoonot N    e ll(    'e:
              ' c.IN blo  'heis<id = ?) + ql("""
           GROUP BY' c.   chock"""
           )ah ob Oc.   chock_ida.   chain)'  )
             WHEc.   chain_id ql(oe:
 se
 dbck_h_i    store.bise, pubkey_h)
)D    

    retw = store.selectrre.o'e:
                            gdbck_hi    chocki    chock)se

        we:
            E   if IN blo  'heisoonot N    e
e:
                            gdbck_hi    chocki IN blo  'heii    chainn])))

    dre.grseeived( = sti    chockore, pubkey_ho IN blo  'hei onot Nash):
  

    retw = store.grseeived_id__last_ob.blockg= ?
  ?
        chockore, pubkey_ho IN blo  'heiyr0n)))

    dre.gsent_id__last_ob.block( = sti    chockore, pubkey_ho'e:
                               
IN blo  'hei onot Nash):
     re. onll("""
            SEL'COALESCE(nd_va_sum, 0),]i.d, ch_last_ob.block"""
              F'LE ch   LEFT    J (

                SEL' c.   chockorSUM(N  txout.txout_va) nd_va_sumid)
              FEe, putidd)
  )
         J ut.txd)
  )
       ob Out.txoe, pubain_ide, puboe, pubain_id)
              J N (t d)
  )
       ob ON (tout.txoin_idN  txout.txain_id)
              J  b blobx  )
       ob O b blobxxinock_id  inoutain_id)
              J  b bl b            ob OC ob.blocks'] b blobx ob.blain_id)
              J LE chain_candid cc ob Occ ob.blocks']b ob.block_id)
  )
          WH'e:
              de, puboe, pubkey_h_id     'e:
              ' c.   chock_id     'e:
              ' c.chain_long ] 1ll( + g= ?
  ?
           l( if IN blo  'heisoonot N    e ll(    'e:
              ' c.IN blo  'heis<id = ?) + ql("""
           GROUP BY' c.   chock"""
           )ah ob Oc.   chock_ida.   chain)'  )
             WHEc.   chain_id ql(oe:
 se
 dbck_h_i    store.bise, pubkey_h)
)D    

    retw = store.selectrre.o'e:
                            gdbck_hi    chocki    chock)se

        we:
            E   if IN blo  'heisoonot N    e
e:
                            gdbck_hi    chocki IN blo  'heii    chainn])))

    dre.gsent( = sti    chockore, pubkey_ho IN blo  'hei onot Nash):
  

    retw = store.gsent_id__last_ob.blockg= ?
  ?
        chockore, pubkey_ho IN blo  'heiyr0n)))

    dre.gbalanNo( = sti    chockore, pubkey_hash):
  

 senii last_ob.blain_iw = store.gsent_id__last_ob.blockg= ?
  ?
        chockore, pubkey_h)se

     rseeivedi last_ob.blain_2 =w = store.grseeived_id__last_ob.blockg= ?
  ?
        chockore, pubkey_h)
ns.        Dealone wfst  raceEco_casact.])

        fi ChOxra_lo(2)= 1:
            last_ob.blain_i= last_ob.blain_2s(e

       
     break]s   we

        stolog.debug("RequeryendlbalanNo: %k !i %d)""",
                   

v last_ob.blaidi last_ob.blain_2)
ns.  e

     rseeivedi last_ob.blain_2 =w = store.grseeivedg= ?
  ?
  ?
        chockore, pubkey_h,w = store.gIN blo  'hei(last_ob.blainn]) 1:
            last_ob.blain_i= last_ob.blain_2s(e

       
     break]s   we

        stolog.e.fo("BalanNo_query affecped by rsorg? %k !i %d)""",
                   

v  last_ob.blaidi last_ob.blain_2)
ns.  e

     senii last_ob.blain_iw = store.gsentg= ?
  ?
  ?
        chockore, pubkey_h,w = store.gIN blo  'hei(last_ob.blain_2))
ns.  e

    last_ob.blain_!= last_ob.blain_2ls   we

        stolog.warnendroBalanNo_query faitaiedueeld inaderghelivity.")se

      

    return Noh):
        returseeived - seni
)))

    dtxrstbi r_full( = sti ss_versorck_h)s( 

     ql("""
     R  retfst  in_addws n 'f er tat.   n Chasaal subst_endNofnse wse:
    nsictOIeys efst dtxrstbi r.( 

     ql(se





    rewl   u.ey_h_ho_in_addw(ss_versorck_h).'f er(])))

     Chuert.txrstbi r_   store, pubocki IN blocki pt_addr_v_ fb):]           store.sql("""
            INSERT I'abt.txrstbi r g= ?
  ?
        re, pubocki IN blocki pn_address_vers,dtxrstbi r= ?
  ?
     )"""
            VALUES, S (?, ?, ?)""",
               (e, putockorIN blocki pt_addr_v_ fb)])))

    dcant_do.txrstbi r_   storpt_addr_v_rIN blockire, pubock):]  
        stolog.e.fog= ?
  ?
     "Nodtxrstbi r    fe, pubain_%korIN blocn_%ko ss_vers '%s')"" ?
        re, pubocki IN blocki    store.bi_rchx(pt_addr_v)])  
        stoChuert.txrstbi r(e, putockorIN blocki pt_addr_v_ ''])))

    ddo.txrstbi r_   storpt_addr_v_rIN blockirfoh'ids, full)s( 

     ql("""
     Ihuertfst dtxrstbi rcks t   ampone wrfo usendrpt_addr_vaht  1:
 e

 are txrstiseetnotrIN block.  R  retfst  bd_co o w   sns.  e

  huerted.'])

    rfo -- st_end,iis wadtxrstbi r usendrpt_addr_v  h eny anNo   s])

    ro wob.block"""
     ids -- seo o wids o  ectOe, pubs txrstiseetnotrIN block s,o e
e:
    dtxrstbi r   ampone wrfo
e:
    dtull --s    fromee, pubain_todtulldtxrstbi r( 

     ql("ns.  e

    lan(ids)s<id1:
       we

    fe, pubainnotrids:
       w  
        stoChuert.txrstbi r(e, putockorIN blocki pt_addr_v_ fb)se

      

    retulan(ids)"ns.  e

 e, pubs ck }
   we

    fe, pubainnotrids:
       w  
 s cdtull[e, pubain] 1:
            s ccdtb:
       w  
        stocant_do.txrstbi r_pt_addr_v_rIN blockire, pubock)
 )
            Econpenvad  
 1:
 e

 fb1 cdtbk+ s[lan(fb)] 1:
         ids1 c e, pubsore.(fb1) 1:
            ids1 oonot N=se

 1:
         ids1 = ieta)ne:
      .  e

 e, pubs[fb1] = ids1 1:
         ids1.in_(e, pubock)
 1:
     bd_co =) 
   we

    ffb1, ids1 on e, pubsoiteritems(ys( 

 1:
     bd_co +iw = stodo.txrstbi r_pt_addr_v_rIN blockirfb1, ids1, full)se





    rewlbd_co)))

    ddoddr_v.txrstbi r_   storpt_addr_v_rIN block)s( 

     ql("""
     Creat  d,w txrstbi r recor r    rIN blaht rpt_addr_v.   ll"""
     anNo   sOIN bl  must hapefst ir txrstbi r ecready recor ed.( 

     ql("ns.  e

 pn_address_vers =    store.bi_(pt_addr_v)ns.  e

 e, pubs ck }   dtxrstbi rcko seo o re, pubock
e:
    dtull    ck }   ee, pubain_todtulldtxrstbi r, Er ot N     ld

   we

    fe, pubockore, pubkey_h,woIN block on in store.selectall("""
            SEL'DISTINCTy')
 )

           de, puboe, pubockoy')
 )

           de, puboe, puboey_ho'e:
                fb ob.block
""
              F' b.blrbid)
              J  b blobx bt ob OC ob.blocks'] t ob.block_id)
  )

         J ut.txdob OCtxinock_id   txoutain_id)
              J e, pub ob Out.txoe, pubain_ide, puboe, pubain_id)
           LEFT    J abt.txrstbi r fb ob Oid)
                    fb pn_address_vers =  =                       fboe, pubain_ide, puboe, pubain_id)
             WHER.R  blain_id = ?" gpt_addr_v_rIN block))s(id)
         e, pubain_ilrnpie, pubain_
y')
            (oIN block in is not Naht 
       w  
        stoCs_descet ed_from(ob.blockilrnpioIN block))ys(       we

    dtull[e, pubain] onot N se)
           fe, pubainnotdtull:( 

 e

       
 conpenvad)s 
   
     tull[e, pubain] o    stotxrstbi r_full(pn_address_verso'e:
                                                   store.bi_se, pubkey_h))

   we

    fe, pubockorsnotdtulloiteritems(ys 1:
            s oonot N:( 

 e

       
 conpenvad)s 
   
       This is to fe, pub's txrstiay.aaranNo  n to '   ch.)s 
   
       Fit  seedin_long match amn_l aarlier txrstbi r.)s 
   
    din_long,din_longain_il0,u = N 0:
         subst_s ck[s[0:(i+1)]    fi ChOxra_lo(lan(s))] 1:
            fanNo   sockirfblan, o_e, putock on in store.selectall("""
                SELEob.blocki LENGTH(txrstbi r),re, pubock
e:
 ""
              F abt.txrstbi r fb
e:
 ""
             WHEpn_address_vers =  =                       fxrstbi r  J (?ll( + g",?" * (lan(s)-1)) + ql("""
                    , ?)" tuple([pt_addr_v]k+ subst_s)ys(      
            fblan >din_long ht     stoCs_descet ed_from("""
                 ob.blockilrnpianNo   sock)ys(      
 s 
   
    din_long,din_longain_ilfblan, o_e, putock'])

 )

     # I  d,No sary, , net fst  d,w fb_toddispendui_ha't from])

 )

     # seedin_long match. 1:
            in_longaina'] is not N,']

             (ooey_ho)row = store.selectg= ?
  ?
        


  "   SELEe, putoey_h    FEe, put    WHEe, pubain_id =o'e:
                 (in_longain,)[(     ))
)

 )

 o.tb o    stotxrstbi r_full('e:
              

 pn_address_versi    store.bi_(ooey_h)[(     ))
)

 )

 max_land= men(lan(r),rlan(o.tb)[(  
 e

       
 s,uledin_long < max_lan ht   [in_long]_i='o.tb[in_long]s(      
 s 
   
    din_lon_k+] 1i 1:
            in_long_i='lan(r):
       w  
        stocant_do.txrstbi r_pt_addr_v_rIN blockire, pubock)
 )
            Econpenvad
 )
         tb o s[0 : (in_lon_k+ 1)] 1:
         ids c e, pubsore.(fb) 1:
            ids oonot N=se

 1:
         ids = ieta)ne:
      .  e

 e, pubs[fb] = ids 1:
         ids.in_(e, pubock)
 1:
     bd_co =) 
   we

    ffb, ids on e, pubsoiteritems(ys( 

 1:
     bd_co +iw = stodo.txrstbi r_pt_addr_v_rIN blockirfb, ids, full)se





    rewlbd_co)))

    dtxrstbi r_ho_in_addwes_   storfb,    chock=ot t):])

     dbtb orfb.'f er(])     

    av [] 1:
     re.n_id[fb[0:(i+1)]    fi ChOxra_lo(lan(tb)[]])

       i   chaina'] is not N,']

   
     re.nray.appg   chain)

   we

    rdbck_hd dr_v on in store.selectall("""
            SELde, puboe, puboey_ho'e:
                fb pn_address_vers
""
              F abt.txrstbi r fb
e:
 ""
          J e, pub ob Ofboe, pubain_ide, puboe, pubain_id)
              J LE chain_candid cc ob Occ ob.blocks']fboob.block)
 )
             WHEfbofxrstbi r  J (?ll( + g",?" * (lan(tb)-1)) + ql()ll( + g \oe:
 se



      ql   i   chaina'onot N    e ll(""                 'cc    chain_id = ?)" tuple(re.k)ys(      
 s 
 in_addws=l   u.ey_h_ho_in_addw(   store.bi_(ss_v[o'e:
                             
     

      store.bi_(dbck_h)) 1:
            in_addw.'f er(].  ampsne w(dbtb)ls  )
    )

        ray.appgin_addw)"ns.  e

    lan(   )a==)  Er (lan(   ) >d1 ht  fbson  e ):]         

    av [fb]    assumaOexacsoin_addwamatchoh):
        returets))

    dre.gtxrstbi r_   storpn_address_vers=ot tordb_e, puboey_h=ot to'e:
                      chock=ot t):] 

     ql("""
     R  retrpn_addr'sdtxrstbi r, Er seedin_lon d # ON muple
e:
    dtxrstbi r nd_vas   i   chaina'] is ngiven, Er ot N    in_addw
e:
    dey_ istiay.aared, Er seedempty'st_endN   in_addwdey_ ay.aared 1:
     rutdey_ isdtxrstbi r.( 

     ql(se





 dr_v_ dbck_h_i    store.bispn_address_vers)ordb_e, puboey_hh):
        s = in store.selectall("""
            SEL'fbofxrstbi r
""
              F abt.txrstbi r fb
e:
 ""
          J e, pub ob Ofboe, pubain_ide, puboe, pubain_id)
              J LE chain_candid cc ob OfC ob.blocks']icoob.block)
 )
             WH' c.chain_long ] 1""                  fb pn_address_vers =  =                  de, puboe, pubkey_h_id?ll( + goe:
 se



      ql   i   chaina'onot N    e ll(""                 'cc    chain_id = ?)"'e:
                            (dr_v_ dbck_h)   i   chainsoonot N    e
e:
                            gdr_v_ dbck_hi    chainn])          iis     s:se

      

    return Noh):
         onll
   we

    rOfC,)  n    s:se

      
    ilan(tb) 1)lan( e ):]         

         onfb
):
        returet")")
# MULTICHAIN STy'

    dre.idumberr #u e transacts( = sti    ch):] 

     ql("""
     Adpdntssee numbergo Etxsonreae, ob.bl s,ue, oein_lrcko    chgo     chain])

     :e, am    chain:])

     :   ret: numbergo Etx, Er -1    st raony_ anreueEr( 

     ql(se





   sN m on-1""       sum   row = store.selectrow("""
            SELESUM( b.blidumortn    F'LE chasummary    WHELE chain_id =        = ?" gd, ch.tx"n])           sum   :])

     


   sN m onsum   r0n
):
        retur sN m
y'

    dre.idumberr #uin_addwes( = sti    ch):] 

     ql("""
     Cd_co see numbergo EuniqueOe, pubs td_ck on ut.txs    fa    chain])

     :e, am    chain:])

     :   ret: numbergo Ein_addwes, Er -1    st raony_ anreueEr( 

     ql(se





   sN m on-1""       bd_co   row = store.selectrow("""
            SELECOUNT(DISTINCTse, pubkey_h))    F ut.tx_detait    WHELE chain_id =        = ?" gd, ch.tx"n])           bd_co   :])

     


   sN m o bd_co   r0n
):
              sN i 1) > 0:
   
     


   sN i -] 1   'NULL_PUBKEY_HASH
):
        retur sN m
y'

    dre.idumberr #uidwets( = sti    ch):] 

     ql("""
     Geo see numbergo Eidwetssoosuek chfa    ch])

     :e, am    ch:])

     :   ret: chteger numbergo Eidwets( 

     ql(se





   sp_iw = store.gidwets(   ch])             sp_'] is not N,']

      

    retulan(  sp)se





    rewl0
y'

    dre.uidwets( = sti    ch):] 

     ql("""
     Geo see r sN m  # lispidwetssjson-rpc ys cht rpssjsonwoIjsel])

     :e, am    ch:])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispidwets")s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dre.uidwetmitananT( = sti    ch, nanT):] 

     ql("""
     Geo see idwet by nanT from lispidwetssjson-rpc ys cht rpssjsonwoIjsel])

     :e, am    ch:])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispidwets", nanT)
):
           ulan(  sp) 1)  lse:
 e


e





   sp_i   spr0ns        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dre.u b.blibbkey_h( = sti    ch,  b.blck_h)s( 

     ql("""
     Ge  ob.bl'e.fo from re.IN blsjson-rpc ys cht rpssjsonwoIjsel])

     :e, am    ch:])

     :e, am  b.blck_h: texsst_endNofnIN blatx_h])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"re.IN bl"o  b.blck_h)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dre.udumberr #upeers( = sti    ch):] 

     ql("""
     Geo see numbergo Econnselek peers
)

     :e, am    ch:])

     :   ret: Ihteger numbergo Ensdes( 

     ql(se





   sp_iw = store.gpeere.fo(   ch])             sp_'] is not N,']

      

    retulan(  sp)se





    rewl0
y'

    dre.upeere.fo( = sti    ch):] 

     ql("""
     Geo e.fo ab.txEconnselek peers by e.vokendsjson-rpc ys cht rre.peere.fo
)

     :e, am    ch:])

     :   ret: JSONwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"re.peere.fo")s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dre.udumberr #uidwe_rc lders( = sti    ch, idwe_rsf):] 

     ql("""
     Geo see numbergo Ein_addwes c ldendEunitsgo Ein idwel])

     :e, am    ch:])

     :e, am idwe_rsf:])

     :   ret: cht] 

     ql("")
    E   chain_id   ch.txns.  e

 ersfix_ilrnpi idwe_rsf.spli.('-')[-1n )h):
        row = store.selectrow("""
            SELEbd_co(DISTINCTre, pubock)
               F adwe_rin_addwgbalanNo
)
             WH'balanNo>0    'adwe_rck=(    SELEadwe_rck    F adwe_    WHELE chain=      ersfix=?)
            = ?" gd, chock' ersfix])y')
       w    oonot N=se

     


   sN m ol0
     "
    elsow
     


   sN m olrnpint(r0ns
):
        retur sN m
y'

    dre.iidwe_rc lders( = sti    ch, idwe_rsf):] 

     ql("""
     Geo a lispNofnseeEin_addwes c ldendEunitsgo Ein idwel])

     :e, am    ch:])

     :e, am idwe_rsf:])

     :   ret: LispNornot N, wt raoeae, lispNe.smenisoonaddinsactaryw = send to fe, pubEind'balanNo.( 

     ql(se


'

    de, s._ectrect):]         

fe, pubore, pubkey_h,re, pubkflags,'balanNo olect]         

    av {oe:
 se



      qe, pub":    store.bi_se, pub),oe:
 se



      qe, pubkey_h":    store.bi_se, pubkey_h),oe:
 se



      qe, pubkflags": e, pubkflags,oe:
 se



      qbalanNo": balanNooe:
 se



      }
   we:
        returet""")
    E   chain_id   ch.txns.  e

 ersfix_ilrnpi idwe_rsf.spli.('-')[-1n )h):
        s = in store.selectall("""
            SEL'p.e, pubore.e, pubkey_h,re.e, pubkflags,'a.balanNo
               F adwe_rin_addwgbalanNo a

 ""
          J e, pub p ob Oaoe, pubain_ideoe, pubain)
)
             WH'balanNo>0    'adwe_rck=(    SELEadwe_rck    F adwe_    WHELE chain=      ersfix=?)
            = ?" gd, chock' ersfix])y')
       w   s oonot N=se

 1:   

    return No    


   sN m ollisp(   (e, s._ect,w   s)s
):
        retur sN m
y'

    dre.ireceniu e transactsiid_json( = sti    ch,llicip=10):] 

     ql("""
     Geo a lispNofnrecenxEcontxrmek  e transacts,udecoden_todjsoh])

     :e, am    ch:])

     :e, amllicip: to fmaxinmum numbergo   e transacts_to    ret])

     :   ret: lispNofsst_endsNordempty lisp.( 

     ql(se

     # Ign st c".tbase  e transacts_wt ra st rao'] is naliv r_urrencyh):
        s = in store.selectall("""
            SEL'DISTINCTr], tx_h"""
            F ut.tx_detait"""
            WHELE chain=      e, pubain_!id =)
  )
      ORDER BYEob.blo  'he_ DESC" inock DESC
)
  )
      LIMILd =        = ?" gd, ch.tx"'NULL_PUBKEY_ID,llicip)s
y')
       w   s oonot N=se

 1:   

     retu[] o    


   sN m ou[]
   we

    r     n    s>se

         iryls  )
    )

     txin_iw = stotx_hbi_rchxint(r0ns
)))))))))))))))djsoh =w = store.graw e transact_decodengd, ch, txin) 1:
  

      
    djsoh in is not Naht djsoh['contxrmasactsi]> > 0:
   
     


 


   sN  ray.appgjsoh)))

 )

     exceptiExcepsactls   we

         passl
):
        retur sN m
y'

    dre.i e transactsi   iidwe_( = sti    ch, idwe_rsf):] 

     ql("""
     Geo a lispNofnse transactsur ldien_toEin idwel.])

     :e, am    ch:])

     :e, amlidwe_rsf:])

     :   ret: lispNofOve ddOut ey_h,r  'he_o  b.blck_h)Nornot o.( 

     ql(se


'

    de, s._ectrect):]         

ftxey_h,r  'he_o  b.blck_h olect]         

    av {o#e:
 se



      qbi_pos":lrnpipos),oe:
 se



      qey_h":  = stotx_hbi_rchxitxey_h),oe:
 se



      qe 'he_":lrnpie 'he_),oe:
 se



      q b.bley_h":  = stotx_hbi_rchxi b.blck_h)oe:
 se



      }
   we:
        returet""")
    Eersfix_ilrnpi idwe_rsf.spli.('-')[-1n )h):
        s = in store.selectall("""
         re.sel'DISTINCTr].], tx_ho  b.IN blo  'heio  b.IN bl tx_h fromEadwe_rtxin_a

 ""
       "".j  b blobx bson Oaoinock=boutain_

 ""
       "".j bx tson Oaoinock=toutain_

 ""
       "".j' b.blrbbson Ob.IN block=bboob.block)
 )
        _wt ra a.adwe_rck=(    SELEadwe_rck    F adwe_    WHELE chain=      ersfix=?)
            or er by  b.IN blo  'heio boutapos adc=        = ?" gd, ch.tx" ersfix)s
y')
       w   s oonot N=se

 1:   

    return Noo    


   sN m ollisp(   (e, s._ect,w   s)s
):
        retur sN m
y'

    dre.i e transactsi   iadwe_rin_addw( = sti    ch, idwe_rsforpn_addr):] 

     ql("""
     Geo a lispNofnse transactsur ldien_toEbostEinrpn_addraht dinridwe_rsf])

     :e, am    ch:])

     :e, amlidwe_rsf:])

     :e, amrpn_addr:])

     :   ret: LispNofnse transactsufr dt o.( 

     ql(se


'

    de, s._ectrect):]         

ftxey_h,r  'he_o  b.blck_h olect]         

    av {oe

       
     #qbi_pos":lrnpipos),oe:
 se



      qey_h":  = stotx_hbi_rchxitxey_h),oe:
 se



      qe 'he_":lrnpie 'he_),oe:
 se



      q b.bley_h":  = stotx_hbi_rchxi b.blck_h)oe:
 se



      }
   we:
        returet""")
    E#dre. e, pub txns.  e

 ss_versore, pubck_h_i    u.decode_e,eblrin_addwgON mu   chgin_addw)"')
       re, pubck_h oonot N=se

 1:   

    return No):
        row = store.selectrow(re.sel e, pubain fromee, pub_wt ra e, pubkey_h_id?ll"o'e:
                               
s(   store.bise, pubey_h),) )y')
       w    oonot N=se

     


    return No):
     e, pubain olrnpint(r0ns""")
    Eersfix_ilrnpi idwe_rsf.spli.('-')[-1n )h):
       aout.txapos,... , aout.txapos adch):
        s = in store.selectall("""
         re.sel'DISTINCTr].], tx_ho  b.IN blo  'heio  b.IN bl tx_h fromEadwe_rtxin_a

 ""
       "".j  b blobx bson Oaoinock=boutain_

 ""
       "".j bx tson Oaoinock=toutain_

 ""
       "".j' b.blrbbson Ob.IN block=bb.IN block_

 ""
       "".j ut.txdoson Oaoinock=ooutain_

 ""
       "".j bxin_detait ison Oaoinock=ioinock)
 )
        _wt ra a.adwe_rck=(    SELEadwe_rck    F adwe_    WHELE chain=      ersfix=?)
            ht d(ooe, pubain=  OR ioe, pubain=?)
            or er by  b.IN blo  'heio boutapos adc=        = ?" gd, ch.tx" ersfixore, pubockire, pubock)s
y')
       w   s oonot N=se

 1:   

    return Noo    


   sN m ollisp(   (e, s._ect,w   s)s
):
        retur sN m
y'

    dre.idumberr #i e transactsi   iadwe_rin_addw( = sti    ch, idwe_rsfore, pubock):] 

     ql("""
     Geo see numbergo Ese transactsur ldien_toEbostEinrpdwe_ ht dinrpn_addr.])

     :e, am    ch:])

     :e, amlidwe_rsf: huminrreaddalelidwe_rsf tor. 111-222-333])

     :e, amre, pubock:])

     :   ret:] 

     ql("")
    Eersfix_ilrnpi idwe_rsf.spli.('-')[-1n )h):
        row = store.selectrow("""
         re.selEbd_co(dispenelEaoinock) fromEadwe_rtxin_a "".j ut.txdoson Oaoinock=ooutain_

 ""
       wt ra a.adwe_rck=(    SELEadwe_rck    F adwe_    WHELE chain=      ersfix=?)
            ht dooe, pubain= =        = ?" gd, ch.tx" ersfixore, pubock])y')
       w    oonot N=se

     


    rewl0
e





    rewlrnpint(r0ns
y'

    dre.idumberr #i e transactsi   iadwe_( = sti    ch, idwe_rsf):] 

     ql("""
     Geo see numbergo Ese transactsur ldien_toEinrpdwe_ s,ue, are  = std  n to Ove dbase.])

     :e, am    ch:])

     :e, amlidwe_rsf: huminrreaddalelidwe_rsf tor. 111-222-333])

     :   ret: cht] 

     ql("")
    Eersfix_ilrnpi idwe_rsf.spli.('-')[-1n )h):
        row = store.selectrow("""
         re.selEbd_co(dispenelEaoinock) fromEadwe_rtxin_a

 ""
       wt ra a.adwe_rck=(    SELEadwe_rck    F adwe_    WHELE chain=      ersfix=?)
        = ?" gd, ch.ck' ersfix])y')
       w    oonot N=se

     


    rewl0
e





    rewlrnpint(r0ns
y'

    ddoesi e transactoexis_( = stir], tx_h):] 

     ql("""
     C,eblcko see    to Ove dbaseEconp chscaEse transact    fargivenOut ey_h.])

     :e, am ], tx_h:])

     :   ret:Eboolean] 

     ql("""
        ], ck_h oonot N=se

 1:   

    retuFalsNse:
     irylse:
 e



e
 dbck_h_i    stock_hinrchxitx_ck_h)s        exceptiTypeEueEr=se

 1:   

    retuFalsNsh):
        row = store.selectrow("""
            SELEEXISTLUE   SELE1    F ut    WHEtx_ck_hrow?)
        = ?" gdbck_hi])y')
       w    oonot N=se

     


    rewlFalsNs    


   sN m olrnpint(r0ns
):
        retuTrva      sN i==1    elFalsNs
y'

    dlispu e transacts( = sti    ch,Ebd_co):] 

     ql("""
     Geo see r sN m  # lisp e transactssjson-rpc ys cht rpssjsonwoIjsel])

     NOTE: This cectddoes is nin_wone wrMN muC  ch v2 scecdalelwectetr.])

     :e, am    ch:])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lisp e transacts"i'"*",Ebd_co)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dre.udumberr #untreams( = sti    ch):] 

     ql("""
     Geo see numbergo Entreams
)

     :e, am    ch:])

     :   ret: Ihteger numbergo Entreams( 

     ql(se





   sp_iw = stolispuntreams(   ch])             sp_'] is not N,']

      

    retulan(  sp)se





    rewl0
y'

    dlispuntream( = sti    ch, nanT):] 

     ql("""
     Geo see r sN m  # lispntreamssjson-rpc ys cht rpssjsonwoIjsel.])

     Werpsk    fardpseificEntream ht dss_bos Ove d.])

     :e, am    ch:])

     :e, am nanT:])

     :   ret:not N orsjsonwoIjsel    fseeEntream])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispntreams", nanT,uTrva)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie

          ulan(  sp) < 1=se

     


    return No):
        ret   spr0n
y'

    dlispuntreams( = sti    ch,Ebd_co=0):] 

     ql("""
     Geo see r sN m  # lispntreamssjson-rpc ys cht rpssjsonwoIjsel.])

     Werpsk    factdntreams ht dss_bos Ove d, sue, as see crea= ssdtxeld.])

     :e, am    ch:])

     :e, am bd_co: by    aN mfact])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





 # lispntreansdntreamrsfdss_bos  bd_ct   ampse:
 e





 # tor. lispntreamss"*" irva 2 -2se:
 e





 # display last twodntreams.se:
 e





 # tor. lispntreamss"*" irva 2 0se:
 e





 # display txrst twodntreams
se:
 e





 #factdntreams 1:
             d_ct <=) >se

 e:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispntreams", "*",uTrva)s         "
    e>se

 e:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispntreams", "*",uTrva,Ebd_co, -bd_co)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dlispuntream_items( = sti    ch,dntreamrsf,Ebd_co=10,   amp=-10):] 

     ql("""
     Geo see r sN m  # lispntreamitemssjson-rpc ys cht rpssjsonwoIjsel.])

     Werpsk    factdntreams ht dss_bos Ove d, sue, as see crea= ssdtxeld.])

     :e, am    ch:])

     :e, am ntreamrsf:])

     :e, am bd_co:])

     :e, am ntamp:])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





 # lispntreamitemssntreamrsfdss_bos  bd_ct   ampdincecor erendse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispntreamitems",dntreamrsf,uTrva,Ebd_co,   amo)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dlispuntream_e, list r_items( = sti    ch,dntreamrsf,Ee, list r,Ebd_co=10,   amp=-10):] 

     ql("""
     Geo see r sN m  # lispntreame, list ritemssjson-rpc ys cht rpssjsonwoIjsel.])

     Werpsk    factdntreams ht dss_bos Ove d, sue, as see crea= ssdtxeld.])

     :e, am    ch:])

     :e, am ntreamrsf:])

     :e, am e, list r:])

     :e, am bd_co:])

     :e, am ntamp:])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





 # lispntreame, list ritems ntreamrsf e, list rpn_addrdss_bos  bd_ct   ampdincecor erendse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispntreame, list ritems",dntreamrsf,Ee, list r,uTrva,Ebd_co,   amo)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dlispuntream_e, list rs( = sti    ch,dntreamrsf,Ee, list r="*"):] 

     ql("""
     Geo see r sN m  # lispntreame, list ritemssjson-rpc ys cht rpssjsonwoIjsel.])

     Werpsk    factdntreams ht dss_bos Ove d, sue, as see crea= ssdtxeld.])

     :e, am    ch:])

     :e, am ntreamrsf:])

     :e, am e, list r:])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





 # lispntreame, list rs ntreamrsf e, list rpn_addrse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispntreame, list rs",dntreamrsf,Ee, list r)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dlispuntream_pubs( = sti    ch,dntreamrsf,Epubs="*"):] 

     ql("""
     Geo see r sN m  # lispntreampubssjson-rpc ys cht rpssjsonwoIjsel.])

     Werpsk    factdpubs ht dss_bos Ove d, sue, as see crea= ssdtxeld.])

     :e, am    ch:])

     :e, am ntreamrsf:])

     :e, am pubs:])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





 # lispntreampubs ntreamrsf pubrse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispntreampubr",dntreamrsf,Epubs)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dlispuntream_pub_items( = sti    ch,dntreamrsf,Entreampub,Ebd_co=10,   amp=-10):] 

     ql("""
     Geo see r sN m  # lispntreampubitemssjson-rpc ys cht rpssjsonwoIjsel.])

     Werpsk    factdntreams ht dss_bos Ove d, sue, as see crea= ssdtxeld.])

     :e, am    ch:])

     :e, am ntreamrsf:])

     :e, am pub:])

     :e, am bd_co:])

     :e, am ntamp:])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





 # lispntreampubitems ntreamrsf e, list rpn_addrdss_bos  bd_ct   ampdincecor erendse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispntreampubitems",dntreamrsf,Entreampub,uTrva,Ebd_co,   amo)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dlispuupgrpnes( = sti    ch):"""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"lispupgrpnes")s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dre.urawmempool( = sti    ch):] 

     ql("""
     Geo see r sN m  # re.rawmempool json-rpc ys cht rpssjsonwoIjsel])

     :e, am    ch:])

     :   ret: jsonwoIjsel (pub ts txin, nd_va tsddins)])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"re.rawmempool",uTrva)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dre.uraw e transact_decoden( = sti    chir], tx_h):] 

     ql("""
     Geo see r sN m  # re.raw e transact json-rpc ys cht rpssjsonwoIjsel])

     :e, am    ch:])

     :   ret: jsonwoIjsel])

     ql("""
     urla=E = store.gurlmit_   ch(   ch])        ON mu   chananTa=E = store.gON mu   chananTmitain(   ch.tx)se





   sp_inot Nse:
     irylse:
 e





   sp_i    u.jsonrpc(ON mu   chananTi'urli'"re.raw e transact",u], tx_ho 1)s        excepti   u.JsonrpcExcepsactrpssN,'  )
    )

    raiExcepsact("JSON-RPC eueEr({0}ys {1}".   mat(toysde, e.messag ))(        exceptiIOEueErrpssN,'  )
    )

    raie
):
        retur sp
y'

    dre.ucdaelsi   itx( = stir], tx_hi    ch):] 

     ql("""
     Geo a lispNofncdaels   scribendcaEse transact])

     :e, am ], tx_h:])

     :e, am    ch:])

     :   ret: lispNofsst_end] 

     ql("""
    ncdaels_inot Nse:
     irylse:
 e





 mytxa=E = stooexpor_rtx_detait(], tx_hi    ch)(        exceptiMal   medHx_hlse:
 e





 mytx_inot e

           mytx_'] is not N,']

      

 d = ieta)ne:
      .      ut.txdin mytx['.tx']s(      
 s 
   
 tmp_iw = store.ucdaelsi   iscripte, pubgd, ch, tx.tx['benscripx'])ne:
          

 d |= ietatmp)ne:
        ncdaels ollisp(d)se





    rewlcdaels
y'

    dre.ucdaelsi   iscripte, pubg = sti    chirscripte, pub):] 

     ql("""
     Geoncdaels   scribend seerscripte, pubgo Ei tx.tl.])

     :e, am    ch:])

     :e, amlscripte, pub:])

     :   ret:ncdaels asllisp,Nordempty lisp   iis  a recognizedrMN muC  ch OP_DROPNor OP_RETURN.] 

     ql("""
    ncdael ou[]
   we

 scrip_rtype,Ove d_id   ch.e, s._tx.tliscript(scripte, pub)
           scrip_rtypa tsdC  ch.SCRIPT_TYPE_
# MULTICH_P2SH:ne:
        ncdaelray.appg'P2SH')
           scrip_rtypa ttu[C  ch.SCRIPT_TYPE_
# MULTICH_STREAM, C  ch.SCRIPT_TYPE_
# MULTICH_STREAM_ITEM]:ne:
        ncdaelray.appg'Stream')
           scrip_rtypa == C  ch.SCRIPT_TYPE_
# MULTICH_FILTER:ne:
        ncdaelray.appg'Filter')
           scrip_rtypa ttu[C  ch.SCRIPT_TYPE_
# MULTICH,dC  ch.SCRIPT_TYPE_
# MULTICH_P2SH]:ne:
        Ove d_i    uore.gON mu   chaop_drop_ve d(scripte, pub)
              Ove da'] is not N,']

             opdroprtypa, nd__i    uoe, s.aop_drop_ve d(ve di    ch)(                   opdroprtypa==   uoOP_DROP_TYPE_ISSUE_ASSET,']

                ncdaelray.appg'Iosue Adwe_')(                el   opdroprtypa==   uoOP_DROP_TYPE_SEND_ASSET,']

                ncdaelray.appg'Adwe_')(                el   opdroprtypa==   uoOP_DROP_TYPE_PERMISSION,']

                ncdaelray.appg'Permissacts')(                el   opdroprtypa==   uoOP_DROP_TYPE_ISSUE_MORE_ASSET,']

                ncdaelray.appg'Reiosue Adwe_')(             "
    e>se

 e:
 e





    ncdaelray.appg'OP_DROP')s         "
    e>se

 e:
 e





 cdaelray.appg'Unknown')s     "
      scrip_rtypa tsdC  ch.SCRIPT_TYPE_
# MULTICH_OP_RETURN,']

         op   retrtypa, nd__i    uoe, s.aop_   ret_ve d(ve di    ch)(               op   retrtypa==   uoOP_RETURN_TYPE_ISSUE_ASSET,']

             cdaelray.appg'Iosue Adwe_')(            el   op   retrtypa ==    uoOP_RETURN_TYPE_MINER_BLOCK_SIGNATURE,']

             cdaelray.appg"MinergSig")s         "
    e>se

 e:
 e





 cdaelray.appg'Metave d')h):
       Protocol 10007s     "
      scrip_rtypa ttu[C  ch.SCRIPT_TYPE_
# MULTICH_SPKH,dC  ch.SCRIPT_TYPE_
# MULTICH_SPKU]:ne:
        Ove d_i    uore.gON mu   chaop_drop_ve d(scripte, pub)
              Ove da'] is not N,']

             opdroprtypa, nd__i    uoe, s.aop_drop_ve d(ve di    ch)(                   opdroprtypa==   uoOP_DROP_TYPE_FOLLOW_ON_ISSUANCE_
ETADATA>se

 e:
 e





    ncdaelray.appg'Adwe_')(                el   opdroprtypa==   uoOP_DROP_TYPE_SPKH_NEW_ISSUE>se

 e:
 e





    ncdaelray.appg'Iosue Adwe_')(                el   opdroprtypa==   uoOP_DROP_TYPE_SPKH_CREATE_STREAM>se

 e:
 e





    ncdaelray.appg'Creat  Stream')(                el   opdroprtypa ==    uoOP_DROP_TYPE_SPKH_CREATE_FILTER>se

 e:
 e





    ncdaelray.appg'Creat  Filter')(                el   opdroprtypa ==    uoOP_DROP_TYPE_SPKH_CREATE_UPGRADE>se

 e:
 e





    ncdaelray.appg"Creat  Upgrpne")(                el   opdroprtypa ==    uoOP_DROP_TYPE_SPKH_APPROVE_UPGRADE>se

 e:
 e





    ncdaelray.appg"Approv  Upgrpne")(                el   opdroprtypa==   uoOP_DROP_TYPE_SPKE>se

 e:
we

         passse

 e:
we

         #cdaelray.appg'SPKE')s         "
    e>se

 e:
 e





 cdaelray.appg'Unknown')s     "
      scrip_rtypa tsdC  ch.SCRIPT_TYPE_
# MULTICH_ENTITY_PERMISSION,'           ncdaelray.appg'Permissacts')(             scrip_rtypa tsdC  ch.SCRIPT_TYPE_
# MULTICH_APPROVE>se





    ncdaelray.appg"Approv  Upgrpne")(             scrip_rtypa tsdC  ch.SCRIPT_TYPE_
# MULTICH_SPKF>se





    ncdaelray.appg"Inline De d")
           "spkd" ttlscripte, pub>se





    ncdaelray.appg"Inline De d")
se





    rewlcdael

    d,w(argr):]


    rew De dS= st(argr)
   